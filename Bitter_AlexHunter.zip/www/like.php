<?php 
include("connect.php"); 
include_once("includes/Tweet.php");
Tweet::like($con, $_GET["tweetId"]);
?>

