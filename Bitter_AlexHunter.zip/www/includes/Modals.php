<script>
//this will display the "reply" to tweet in a modal dialog window.

    $(document).ready(function() {
        //adds the tweet id to the modal so the modal can be used by any comment button
        $('#add_comment_Modal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var tweet_id = button.data('id');
            var modal = $(this);
            modal.find('#id').val(tweet_id);
        });
    });//end of ready event handler
</script>

<!--Bootstrap Modals-->
<div id="add_comment_Modal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Header -->
            <div class="modal-header">
                <h4 class="modal-title">Add comment</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Body -->
            <div class="modal-body">
                <form method="POST" id="insert_comment_form" action="reply_proc.php">
                    <input type="text" hidden name="id" id="id" readonly />
                    <textarea required name="myComment" id="myComment" class="form-control" placeholder="Enter your comment"></textarea>
                    <input style="float: right; margin-top: 1em;" type="submit" name="insert" id="insert" value="Submit" class="btn btn-success" />
                </form>
            </div>
        </div>
    </div>
</div>
