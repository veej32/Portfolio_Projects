<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Message
 *
 * @author alex2
 */
class Message {
    private $id;
    private $fromId;
    private $toId;
    private $messageText;
    private $dateSent;
    
    public function __construct(int $id, int $from_id, int $to_id, String $message_text, String $date_sent) {
        $this->id = $id;
        $this->fromId = $from_id;
        $this->toId = $to_id;
        $this->messageText = $message_text;
        $this->dateSent = $date_sent;
    }

    public function __destruct() {
        //nothing for now
    }
    public function __get($n){
        return $this->$n;
    }
    public function __set($property, $value){
        $this->$property = $value;
    }
    
    public function timeSinceSent () {
        date_default_timezone_set("America/Halifax");
        $now = new DateTime();
        $timeSent = new DateTime($this->dateSent);  
        $interval = $now->diff($timeSent);
 
        if ($interval->y > 1)     return  $interval->format("%y years") . " ago";
        elseif ($interval->y > 0) return $interval->format("%y year") . " ago";
        elseif ($interval->m > 1) return $interval->format("%m months") . " ago";
        elseif ($interval->m > 0) return $interval->format("%m month") . " ago";
        elseif ($interval->d > 1) return $interval->format("%d days") . " ago";
        elseif ($interval->d > 0) return $interval->format("%d day") . " ago<BR>";
        elseif ($interval->h > 1) return $interval->format("%h hours") . " ago";
        elseif ($interval->h > 0) return $interval->format("%h hour") . " ago";
        elseif ($interval->i > 1) return $interval->format("%i minutes") . " ago";
        elseif ($interval->i > 0) return $interval->format("%i minute") . " ago";
        elseif ($interval->s > 1) return $interval->format("%s seconds") . " ago";
        elseif ($interval->s > 0) return $interval->format("%s second") . " ago";
        else return "just now";
    }
    
    public static function sendMessage(mysqli $con, int $to_id, String $message) {
        $current_user_id = $_SESSION["SESS_MEMBER_ID"];
        if ($current_user_id == $to_id){
            $msg = "You can't message yourself. That would be weird.";           
        }
        else {
            $current_user = User::getUserByUserId($con, $current_user_id);
            if ($current_user->checkIfFollowing($con, $to_id)) {
                $sql = "INSERT INTO `messages` (`from_id`,`to_id`,`message_text`) "
                        . "VALUES (" . $current_user_id 
                        . "," . $to_id 
                        . ",'" . mysqli_real_escape_string($con,$message) . "');";
                $msg = $sql;
                if ($result = mysqli_query($con, $sql)){
                    if (mysqli_affected_rows($con) == 1) $msg = "MESSAGE SENT!";               
                    else {
                        $msg = "ERROR SENDING MESSAGE! PLEASE CONTACT BITTER SUPPORT!";
                    }
                }
                else {
                    $msg .= "Database Error: " . $con->error ; 
                }
                
            }
            else $msg = "You can't direct message users you're not following!";
        }
        $msg = addslashes($msg);
        header("location:DirectMessage.php?message=$msg");  
    }
}
