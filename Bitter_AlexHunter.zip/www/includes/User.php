<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * @author Alex Hunter
 */
class User {
    
    private $userId;
    private $userName;
    private $password;
    private $firstName;
    private $lastName;
    private $address;
    private $province;
    private $postalCode;
    private $contactNo;
    private $email;
    private $dateAdded;
    private $profImage;
    private $location;
    private $description;
    private $url;
    
    public function __construct($userId, $userName, $password, $firstName, $lastName, $address, $province, $postalCode, 
            $contactNo, $email, $dateAdded, $profImage, $location, $description, $url) {
         $this->userId = $userId;
         $this->userName = $userName;
         $this->password = $password;
         $this->firstName = $firstName;
         $this->lastName = $lastName;
         $this->address = $address;
         $this->province = $province;
         $this->postalCode = $postalCode;
         $this->contactNo = $contactNo;
         $this->email = $email;
         $this->dateAdded = $dateAdded;
         $this->profImage = $profImage;
         $this->location = $location;
         $this->description = $description;
         $this->url = $url;
    }
    
    public static function getUserByUserId(MySqli $con, int $userId){
        $sql = "SELECT * FROM users WHERE user_id = $userId";
        $result = mysqli_query($con, $sql);

        if ($row=mysqli_fetch_array($result)){
            $user = new User(
                $userId, $row["screen_name"], $row["password"],$row["first_name"], $row["last_name"], 
                $row["address"], $row["province"], $row["postal_code"],$row["contact_number"], $row["email"], 
                $row["date_created"], $row["profile_pic"], $row["location"], $row["description"], $row["url"]);
            return $user;
        }
        return null; //return null if user not found           
    }
    
    public static function getUserByScreenName(MySqli $con, String $screenName, bool $caseSensitive) {
        if (!$caseSensitive) $strSql = "select * from users where lower(screen_name) = '" . strtolower(mysqli_real_escape_string($con, $screenName)) . "'";
        else "select * from users where screen_name = '" . mysqli_real_escape_string($con, $screenName) . "'";
        
        $result = mysqli_query($con, $strSql);
        if ($row=mysqli_fetch_array($result)){
            $user = new User(
                $row["user_id"], $screenName, $row["password"],$row["first_name"], $row["last_name"], 
                $row["address"], $row["province"], $row["postal_code"],$row["contact_number"], $row["email"], 
                $row["date_created"], $row["profile_pic"], $row["location"], $row["description"], $row["url"]);
            return $user;
        }
        return null; //return null if user can't be found
    }
    
    public static function getUserByTweetId(mysqli $con, int $tweetId) {
        $sql = "SELECT users.* FROM users INNER JOIN tweets 
            ON users.user_id = tweets.user_id WHERE tweets.tweet_id = $tweetId";
        $result = mysqli_query($con, $sql);
        if ($row=mysqli_fetch_array($result)){
            $user = new User(
                $row["user_id"], $row["screen_name"], $row["password"],$row["first_name"], $row["last_name"], 
                $row["address"], $row["province"], $row["postal_code"],$row["contact_number"], $row["email"], 
                $row["date_created"], $row["profile_pic"], $row["location"], $row["description"], $row["url"]);
            return $user;
        }
        return null; //return null if user not found           
    }
    
    //gets and returns all messages for this user
    public function GetAllMessages($con){
        include_once("Includes/Message.php");
        $messages = array(); 
        
        $sql = "SELECT * FROM messages WHERE"
            . " to_id = " . $this->userId 
            . " OR from_id = " . $this->userId 
            . " ORDER BY date_sent DESC;";
         
        if ($result = mysqli_query($con, $sql)) {
             while ($row=mysqli_fetch_array($result)){
                $message = new Message($row["id"], $row["from_id"], $row["to_id"], $row["message_text"], $row["date_sent"]);
                array_push($messages, $message);
            }
        }
        return $messages;
    }
    

    //inserts a new user in the database 
    public static function createUser(mysqli $con, User $user){
        //make sure user doesn't exist - just in case
        $preUser = User::getUserByScreenName($con, $user->userName, false);
        if ( $preUser != null) { 
            $msg = "ERROR: USERNAME ALREADY EXISTS!";
            header("location:signup.php?message=$msg");
        }
        else {
            //encrypt password for database storage
            $user->password = password_hash($user->password, PASSWORD_DEFAULT);

            //create sql insert statement
            $sql = "INSERT INTO .`users` (`first_name`,`last_name`,`screen_name`,`password`,`address`,`province`,`postal_code`,
                `contact_number`,`email`,`url`,`description`,`location`,`date_created`,`profile_pic`)VALUES
            ('" . mysqli_real_escape_string($con, $user->firstName) . "',   '" . mysqli_real_escape_string($con, $user->lastName) . "',
            '" . mysqli_real_escape_string($con, $user->userName) . "',     '" . mysqli_real_escape_string($con, $user->password) . "',
            '" . mysqli_real_escape_string($con, $user->address) . "',      '" . mysqli_real_escape_string($con, $user->province) . "',
            '" . mysqli_real_escape_string($con, $user->postalCode) . "',   '" . mysqli_real_escape_string($con, $user->contactNo) . "',
            '" . mysqli_real_escape_string($con, $user->email) . "',        '" . mysqli_real_escape_string($con, $user->url) . "',
            '" . mysqli_real_escape_string($con, $user->description) . "',  '" . mysqli_real_escape_string($con, $user->location) . "',
            '" . mysqli_real_escape_string($con, $user->dateAdded) . "', '');";   

            //execute statement and evaluate
            mysqli_query($con, $sql);
            if (mysqli_affected_rows($con) == 1) {
                $msg = "INSERT SUCCESSFUL";       
                header("location:login.php?message=$msg"); 
            }
            else {
                $msg = "ERROR INSERTING RECORD! PLEASE CONTACT BITTER SUPPORT!";  
                header("location:signup.php?message=$msg"); 
            }
        }
        
    }
    
    //performs login functionality
    public static function login(mysqli $con, $userName, $password){
        $user = User::getUserByScreenName($con, $userName, false);//get user by screen (case-insensitive)
        if ($user != null && password_verify($password, $user->password) == 1){           
            session_start();
            $_SESSION['SESS_FIRST_NAME'] = $user->firstName;
            $_SESSION['SESS_LAST_NAME'] = $user->lastName;
            $_SESSION['SESS_MEMBER_ID'] = $user->userId;
            $msg = "Login Successful!";
            header("location:Index.php");
        }
        else {
            $msg = "Unsuccessful login. Please try again.";
            header("location:Login.php?message=$msg");
        }
    }
    
    //performs following functionality
    public static function follow($con, $followerId, $followeeId) {
        //make sure the user doesn't  follow themself 
        if ($followerId == $followeeId) $msg = "You cannot follow yourself!";
        else {
            //select statement to check if follower is already following. 
            $sql_select = "SELECT from_id FROM follows WHERE from_id = $followerId AND to_id = $followeeId";
            //execute select statement
            if ($result = mysqli_query($con, $sql_select)) {
                //check if user is already following them
                if (mysqli_fetch_array($result)['from_id']) $msg = "You are already following that user!";
                else {//good path - try to insert record and create a success message
                    $sql_insert = "INSERT INTO `follows` (`from_id`, `to_id`)VALUES ($followerId, $followeeId)";
                    mysqli_query($con, $sql_insert); 
                    if (mysqli_affected_rows($con) == 1) $msg = "Following Successful!";
                    else $msg = "ERROR ON INSERT! Please contact Bitter Support!";    
                }   
            }
            else { $msg = "ERROR ON SELECT! Please contact Bitter Support!";}
        }
        header("location:index.php?message=$msg");
    }
    
    //performs photo editing functionality
    public static function editPhoto(mysqli $con, $MAX_FILE_SIZE, $failPage, $successPage){
        if (empty($_FILES["photo"])){
            $message = "Please upload a profile picture.";
            header("location:" . $failPage . "?message=$message");
        }
        if ($_FILES['photo']['size'] > $MAX_FILE_SIZE) {
            $message = "File must be less than 5MB!";
            unlink($_FILES['photo']['tmp_name']); //delete the file to save space
            header("location:" . $failPage . "?message=$message");
        } 
        else {
            session_start();
            $user_id = $_SESSION["SESS_MEMBER_ID"];
            $photoId = $user_id . time() . $_FILES['photo']['name'];
            $destFile = "images/profilepics/" . (string) $photoId; 
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $destFile)){  
                $sql = "update users set profile_pic = '" . mysqli_real_escape_string($con, $photoId) . "' where user_id = " . $user_id; 
                mysqli_query($con, $sql);
                if (mysqli_affected_rows($con) == 1) { //good path - everything worked
                    $message = "UPDATE SUCCESSFUL";
                    header("location:" . $successPage . "?message=$message");;
                }
                else {
                    $message = "ERROR ON UPDATE";
                    unlink($_FILES['photo']['tmp_name']); //delete the file to save space
                    header("location:" . $failPage . "?message=$message");
                }
            }
            else {
                $message = "ERROR MOVING FILE!";
                unlink($FILES['photo']['tmp_name']); //delete the file to save space 
                header("location:" . $failPage . "?message=$message");
            }
        }
    }
    
    //returns an array of users that the current user can follow
    public static function whoToTroll(mysqli $con){
        $id = $_SESSION["SESS_MEMBER_ID"];
        $sql = "SELECT * "
        . "FROM users WHERE user_id != $id AND user_id NOT IN "
        . "(SELECT to_id FROM follows WHERE from_id = $id)";

        //put users for "who to troll" into an array and randomize them
        $whoToTroll = [];
        if ($result = mysqli_query($con, $sql)){ 
            while ($row = mysqli_fetch_array($result)){
                $trollee = new User(
                    $row["user_id"], $row["screen_name"], $row["password"],$row["first_name"], $row["last_name"], 
                    $row["address"], $row["province"], $row["postal_code"],$row["contact_number"], $row["email"], 
                    $row["date_created"], $row["profile_pic"], $row["location"], $row["description"], $row["url"]);
                $whoToTroll[sizeof($whoToTroll)] = $trollee;
            }
        }
        //randomize result
        shuffle($whoToTroll);
        
        //display users to troll
        $i = 0;
        foreach ($whoToTroll as $user){
            if ($i === 3) break;
            if ($user->profImage != "") $user_pic = $user->profImage;
            else $user_pic = "default.jfif";
            echo "<a href='userpage.php?user_id=" . $user->userId . "'>" 
                . "<img class='bannericons' src='Images/profilepics/" . $user_pic . "'> ";
                echo substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25) 
                . "</a><br>";
                echo "<form method='post' action='follow_proc.php?user_id=" . $user->userId . "'>" 
                . "<input type='submit' name='follow_button' id='follow_button' value='follow' class='followbutton btn btn-primary'/>"
                . "</form><hr>";
            $i++;
        }
    }
    public function search(mysqli $con, String $search){
        $return = null;
        //get users matching criteria
        $sql_users = "SELECT * FROM `users`"
            . " WHERE (UPPER(first_name) LIKE '%$search%')" 
            . " OR (UPPER(last_name) LIKE '%$search%')" 
            . " OR (UPPER(screen_name) LIKE '%$search%');";
        if ($result = mysqli_query($con, $sql_users)){ 
            $return = array('users' => [], 'tweets'=>[] );
            while ($row = mysqli_fetch_array($result)){
                $user = new User(
                    $row["user_id"], $row["screen_name"], $row["password"],$row["first_name"], $row["last_name"], 
                    $row["address"], $row["province"], $row["postal_code"],$row["contact_number"], $row["email"], 
                    $row["date_created"], $row["profile_pic"], $row["location"], $row["description"], $row["url"]);
                $return['users'][sizeof($return['users'])] = $user;
            }
        }
        //get tweets matching criteria
        $sql_tweets = "SELECT * FROM tweets WHERE UPPER(tweet_text) LIKE '%$search%' AND reply_to_tweet_id = 0;";
        if ($result = mysqli_query($con, $sql_tweets)){ 
            while ($row = mysqli_fetch_array($result)){
                $tweet = new Tweet($row["tweet_id"], $row["original_tweet_id"], $row["tweet_text"], $row["reply_to_tweet_id"], $row["user_id"], $row["date_created"]);
                $return['tweets'][sizeof($return['tweets'])] = $tweet;
            }
        }
        return $return;
    }
     //returns an array of users that the current user can follow
    public function followersYouKnow(mysqli $con){
        $id = $_SESSION["SESS_MEMBER_ID"];
        $sql = "SELECT * "
        . "FROM users WHERE user_id != $id AND user_id IN "
        . "(SELECT to_id FROM follows WHERE from_id = $id)"
        . "AND user_id IN (SELECT to_id FROM follows WHERE from_id = " . $this->userId . ")";

        //put users for "who to troll" into an array and randomize them
        $followers = [];
        if ($result = mysqli_query($con, $sql)){ 
            while ($row = mysqli_fetch_array($result)){
                $followee = new User(
                    $row["user_id"], $row["screen_name"], $row["password"],$row["first_name"], $row["last_name"], 
                    $row["address"], $row["province"], $row["postal_code"],$row["contact_number"], $row["email"], 
                    $row["date_created"], $row["profile_pic"], $row["location"], $row["description"], $row["url"]);
                $followers[sizeof($followers)] = $followee;
            }
        }
        //randomize result
        shuffle($followers);
        echo "<div class=\"bold\" style=\"padding-left:1em\">" . sizeof($followers) . "&nbsp;Followers you know<BR>";
        //display users to troll
        $i = 0;
        foreach ($followers as $user){
            if ($i === 4) break;
            if ($user->profImage != "") $user_pic = $user->profImage;
            else $user_pic = "default.jfif";
            echo "<a href='userpage.php?user_id=" . $user->userId . "' >" 
                . "<img style='margin-bottom:0.5em' class='bannericons' src='Images/profilepics/" . $user_pic . "'> ";
                echo substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 20) 
                . "</a><br>";
            $i++;
        }
        echo "</div>";
    }
 
    
    //returns the profile picture name
    public static function getPFP(mysqli $con, $userId){
        $sql = "SELECT profile_pic FROM users WHERE user_id = '$userId'";
        $result = mysqli_query($con, $sql);
        if ($row=mysqli_fetch_array($result)){                
            if ($row['profile_pic'] != ""){
                return $row['profile_pic'];
            }
            else {
                return "default.jfif";
            }
        } 
        return null;
    }
    
    //gets how many tweets they made
    public function getNumTweets(mysqli $con){   
        $sql = "SELECT COUNT(tweet_id) AS `amount` FROM tweets
	WHERE reply_to_tweet_id = 0 AND user_id = " . $this->userId;      
        
        $result = mysqli_query($con, $sql);
        if (!$result) return "ERROR"; 
        else if ($row = mysqli_fetch_array($result)) return $row['amount'];
        else return "ERROR";
    }
    //gets how many users they are following
    public function getNumFollowing(mysqli $con){
        $sql = "SELECT COUNT(follow_id) AS `amount` FROM `bitter-alexhunter`.follows WHERE from_id = " . $this->userId;
        $result = mysqli_query($con, $sql);
        if (!$result) return "DB ERROR"; 
        else if ($row = mysqli_fetch_array($result)) return $row['amount'];
        else return "ROW ERROR";
    }
    
    public function getNumFollowers(mysqli $con){
        $sql = "SELECT COUNT(follow_id) AS `amount` FROM `bitter-alexhunter`.follows WHERE to_id = " . $this->userId;
        $result = mysqli_query($con, $sql);
        if (!$result) return "DB ERROR"; 
        else if ($row = mysqli_fetch_array($result)) return $row['amount'];
        else return "ROW ERROR";
    }
    
    public function checkIfFollowing(mysqli $con, int $id){
        $sql = "SELECT * FROM follows
        WHERE from_id = " . $this->userId . " AND to_id = " . $id;
        $result = mysqli_query($con, $sql);
        if (mysqli_fetch_array($result)) return true;
        else return false;
        
    }
    public function checkIfFollowedBy(mysqli $con, int $id){
        $sql = "SELECT * FROM follows
        WHERE from_id = " . $id . " AND to_id = " . $this->userId;
        $result = mysqli_query($con, $sql);
        if (mysqli_fetch_array($result)) return true;
        else return false;
    }
    
    public function GetLikes(mysqli $con){
        include_once("Includes/Like.php");
        $id = $_SESSION["SESS_MEMBER_ID"];
        $likes = array();
         
        //get all likes that have tweet_id matching any of the user's tweets' tweet_ids. sort by order descending
        $sql = "SELECT like_id, tweet_id, user_id, date_created from likes WHERE 
                tweet_id IN(SELECT tweet_id FROM tweets WHERE user_id = $id)
                ORDER BY date_created DESC;";
        $result = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($result)){
                $like = new Like($row['like_id'], $row['tweet_id'], $row['user_id'], $row['date_created']);
                array_push($likes, $like);
        }
        return $likes;
    }
    
    public function GetRetweets(mysqli $con){
        $id = $_SESSION["SESS_MEMBER_ID"];
        $retweets = array();
        //get all retweets with the original tweet id being a tweet the user made
        $sql = "SELECT * from tweets WHERE 
	original_tweet_id IN(SELECT tweet_id FROM tweets WHERE user_id = $id )
        AND reply_to_tweet_id = 0 ORDER BY date_created DESC;";
        $result = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($result)){
                $tweet = new Tweet($row['tweet_id'], $row["original_tweet_id"], $row["tweet_text"], $row["reply_to_tweet_id"], $row["user_id"], $row["date_created"]);
                array_push($retweets, $tweet);
        }
        return $retweets;
    }
    
    public function GetReplies(mysqli $con){
        $id = $_SESSION["SESS_MEMBER_ID"];
        $replies = array();
        //get all retweets with the original tweet id being a tweet the user made
        $sql = "SELECT * from tweets WHERE 
	reply_to_tweet_id IN(SELECT tweet_id FROM tweets WHERE user_id = $id )
        ORDER BY date_created DESC;";
        $result = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($result)){
                $tweet = new Tweet($row["tweet_id"], $row["original_tweet_id"], $row["tweet_text"], $row["reply_to_tweet_id"], $row["user_id"], $row["date_created"]);
                array_push($replies, $tweet);
        }
        return $replies;
    }
    
    
    
    
    public function __destruct() {
        //nothing for now
    }
    
    public function __get($n){
        return $this->$n;
    }
    public function __set($property, $value){
        $this->$property = $value;
    }
    
}
