<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * @author Alex Hunter
 */
class Tweet {
    //put your code here
    
    //things like postTweet, getTweets, reTweet, reply, dateposted 
    
    private $tweetId;
    private $originalTweetId;
    private $tweetText;
    private $replyToTweetId;
    private $userId;
    private $dateAdded;
    
    public function __construct($tweetId, $originalTweetId, $tweetText, $replyToTweetId, $userId, $dateAdded){
        $this->tweetId = $tweetId;
        $this->originalTweetId = $originalTweetId;
        $this->tweetText = $tweetText;
        $this->replyToTweetId = $replyToTweetId;
        $this->userId = $userId;
        $this->dateAdded = $dateAdded;
    }
    
    public static function getTweet(mysqli $con, int $tweetId){
        $sql = "SELECT tweet_id, original_tweet_id, tweet_text, reply_to_tweet_id, user_id, date_created "
            . "FROM tweets WHERE tweet_id = $tweetId";
        $result = mysqli_query($con, $sql);
        if (!$result) {
            //echo ("Error getting tweet. <br> description: " . $con->error);
            return null;
        }
        else if ($row = mysqli_fetch_array($result)){
            $tweet = new Tweet($tweetId, $row["original_tweet_id"], $row["tweet_text"], $row["reply_to_tweet_id"], $row["user_id"], $row["date_created"]);
            return $tweet;
        }
        else return null;
    }
    public static function getReplies(mysqli $con, int $tweetId){
        $sql = "SELECT tweet_id, original_tweet_id, tweet_text, reply_to_tweet_id, user_id, date_created "
            . "FROM tweets WHERE reply_to_tweet_id = $tweetId";
        $result = mysqli_query($con, $sql);
        if (!$result) {
            echo ("Error getting replies. <br> description: " . $con->error);
            return null;
        }
        $replies = [];
        while ($row = mysqli_fetch_array($result)){
            //create new tweet with row info
            $reply = new Tweet($row["tweet_id"], $row["original_tweet_id"], $row["tweet_text"], $row["reply_to_tweet_id"], $row["user_id"], $row["date_created"]);
            //add tweet to array
            $replies[sizeof($replies)] = $reply;
        }
        return $replies;
    }
    public static function postTweet(mysqli $con, $myTweet){
        //create sql insert statement
        $sql = "INSERT INTO `tweets`
        (`tweet_text`,`user_id`)
        VALUES
        ('" . mysqli_real_escape_string($con, $myTweet->tweetText) . "'," . $myTweet->userId . ");";

        //run the sql statement
        mysqli_query($con, $sql); 

        //make sure it worked
        if (mysqli_affected_rows($con) == 1) {
            $msg = "TWEET SUCCESSFUL!";
        }
        else {
            //$msg = "ERROR ON INSERT";
            $msg = "ERROR TWEETING! PLEASE CONTACT BITTER SUPPORT!";
        }
        header("location:index.php?message=$msg");    
    }
    
   
    public static function displayTweets(mysqli $con, int $id, bool $includeFollowees){
            $tweets = Tweet::getTweetsForUser($con, $id, $includeFollowees, 10);
            foreach ($tweets as $tweet){
                echo "<div style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;'> ";
                //check if it is a retweet
                if ($tweet->originalTweetId != 0 ){
                    $reposter = User::getUserByTweetId($con, $tweet->userId);
                    $reposterLinkText = substr($reposter->firstName . " " . $reposter->lastName . " @" . $reposter->userName, 0, 25);
                    $repostee = User::getUserByTweetId($con, $tweet->originalTweetId);
                    if ($repostee != null) $reposteeText = substr($repostee->firstName . " " . $repostee->lastName, 0, 15);
                    echo '<a href = "userpage.php?user_id='.$tweet->userId.'">'.$reposterLinkText.'</a>  ';
                    date_default_timezone_set("America/Halifax");
                    echo Tweet::timeFromPost($tweet->dateAdded);   
                    if ($repostee != null) echo "<strong> retweeted from $reposteeText </strong><BR>";        
                }
                else { //normal post
                    $user = User::getUserByUserId($con, $tweet->userId);
                    $tweetLinkText = substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25);
                    echo '<a href = "userpage.php?user_id='.$tweet->userId.'">'.$tweetLinkText.'</a>'.' ';
                    date_default_timezone_set("America/Halifax");
                    echo Tweet::timeFromPost($tweet->dateAdded) . "<BR>";                                       
                }
                echo $tweet->tweetText . "<BR>";
                if ($tweet->testIfLiked($con, $id)) echo '<img class="smallicon" src="images/liked.png" style="height:30px;width:30px">';
                else echo '<a href="like.php?tweetId='.$tweet->tweetId.'"><img class="smallicon" src="images/like.png" style="height:30px;width:30px"></a>';     
                echo $tweet->getLikeCount($con);
                echo '<a href="retweet.php?tweetId=' . $tweet->tweetId . '"><img class="smallicon" src="images/retweet.png" style="height:30px;width:30px"></a>';
                //echo '<a href="reply_proc.php?tweetId=' . $tweet->tweetId . '"><img class="smallicon" src="images/reply.png"></a>';
                 echo '<img data-toggle="modal" data-target="#add_comment_Modal" data-id="' . $tweet->tweetId .'" style="height: 30px; margin-left: 0.3em;" src="images/reply.png">';
                
                $replies = Tweet::getReplies($con, $tweet->tweetId);
                foreach ($replies as $reply){
                    echo "<hr>";
                    echo "<div style='margin-left:2em'>";
                    $user = User::getUserByUserId($con, $reply->userId);
                    $tweetLinkText = substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25);
                    echo '<a href = "userpage.php?user_id='.$tweet->userId.'">'.$tweetLinkText.'</a>'.' ';
                    //date_default_timezone_set("America/Halifax");
                    echo Tweet::timeFromPost($reply->dateAdded) . "<BR>";   
                    echo $reply->tweetText . "<BR>";
                    echo "</div>";
                }
                echo '</div>';      
            }
    }
    public static function getTweetsForUser(mysqli $con, int $userId, bool $includeFollowees, int $limit){
        
        if ($limit == 0) $limitMsg = "";
        else $limitMsg = " LIMIT $limit";
        if ($includeFollowees) {
            $sql="SELECT tweet_id, original_tweet_id, tweet_text, reply_to_tweet_id, tweets.user_id, tweets.date_created "
            . "FROM users INNER JOIN tweets "
            . "ON users.user_id = tweets.user_id "
            . "WHERE reply_to_tweet_id = 0 AND " //make sure we don't get replies in current user's main feed.
            . "(users.user_id IN (SELECT follows.to_id FROM follows WHERE follows.from_id = '$userId') OR users.user_id = '$userId') "
            . "ORDER BY tweets.tweet_id DESC" . $limitMsg ;
        } else {
            $sql="SELECT tweet_id, original_tweet_id, tweet_text, reply_to_tweet_id, tweets.user_id, tweets.date_created "
            . "FROM users INNER JOIN tweets "
            . "ON users.user_id = tweets.user_id "
            . "WHERE reply_to_tweet_id = 0 AND " //make sure we don't get replies in current user's main feed.
            . "users.user_id = '$userId' "
            . "ORDER BY tweets.tweet_id DESC" . $limitMsg;
        }
        
        $result = mysqli_query($con, $sql);
        if (!$result) { //executes if there is a database error
            //echo("DATABASE ERROR WHILE GETTING TWEETS FOR USER!<BR>Descripion: " . $con->error . "<BR>");
            return null; 
        }
        $tweets = [];
        while ($row = mysqli_fetch_array($result)){
            //create new tweet with row info
            $tweet = new Tweet($row["tweet_id"], $row["original_tweet_id"], $row["tweet_text"], $row["reply_to_tweet_id"], $row["user_id"], $row["date_created"]);
            
            //add tweet to array
            $tweets[sizeof($tweets)] = $tweet;
        }
        return $tweets;
    }

    public static function like(mySqli $con, $tweetId) {
        session_start();
        if (!isset($_SESSION["SESS_MEMBER_ID"])) header("location:Login.php");
        else {
            $likedTweet = Tweet::getTweet($con, $tweetId);
            $currentUserId = $_SESSION["SESS_MEMBER_ID"];
            if ($likedTweet->testIfLiked($con,$currentUserId)) $msg = "You already liked that tweet!";
            else {
                //create sql insert statement
                $sql = "INSERT INTO `likes`
                (`tweet_id`,`user_id`)
                VALUES 
                 (" . $likedTweet->tweetId . ","
                    . $currentUserId . ");";
                echo $sql;
                //run statement
                if (!mysqli_query($con, $sql)) $msg = "DATABASE ERROR INSERTING LIKE! PLEASE CONTACT BITTER SUPPORT!";
                else if (mysqli_affected_rows($con) == 1) $msg = "LIKE SUCCESSFUL!"; 
                else $msg = "ERROR! LIKE NOT INSERTED! PLEASE CONTACT BITTER SUPPORT!";
            }

            header("location:index.php?message=$msg");          
        }
    }
    public static function retweet(mysqli $con, $tweetId){
        session_start();
        if (!isset($_SESSION["SESS_MEMBER_ID"])) header("location:Login.php");
        else {
            $retweetedTweet = Tweet::getTweet($con, $tweetId);
            $currentUserId = $_SESSION["SESS_MEMBER_ID"];
            //create sql insert statement
            if ($retweetedTweet->originalTweetId == 0){
                //original retweet
                $sql = "INSERT INTO `tweets` (`tweet_text`,`user_id`,`original_tweet_id`) VALUES
                ('" . mysqli_real_escape_string($con, $retweetedTweet->tweetText) . "'," . $currentUserId . "," . $retweetedTweet->tweetId . ");";
            }
            else {
                //retweet to a retweet
                $sql = "INSERT INTO `tweets` (`tweet_text`,`user_id`,`original_tweet_id`) VALUES
                ('" . mysqli_real_escape_string($con, $retweetedTweet->tweetText) . "'," . $currentUserId . "," . $retweetedTweet->originalTweetId . ");";
            }
            
            //run the sql statement
            if (!mysqli_query($con, $sql)) $msg = "DATABASE ERROR INSERTING RETWEET! PLEASE CONTACT BITTER SUPPORT!"; 
            else if (mysqli_affected_rows($con) == 1) $msg = "RETWEET SUCCESSFUL!"; 
            else $msg = "ERROR INSERTING RECORD FOR RETWEET! PLEASE CONTACT BITTER SUPPORT!";
            header("location:index.php?message=$msg");  
        }
    }
    public static function reply(mysqli $con, $myComment, int $tweetId){
            //echo " My comment: " . $myComment . "<BR>" . "the tweet's id: " . $tweetId . "<BR>";
        $currentUserId = $_SESSION['SESS_MEMBER_ID'];
            //echo $currentUserId . "<BR>";
        $oldTweet= Tweet::getTweet($con, $tweetId);
        $ogTweetId = $oldTweet->originalTweetId;

            //echo "original tweet id: " . $oldTweet->originalTweetId . "<BR>";
        $sql = "INSERT INTO `tweets`
            (`tweet_text`,`user_id`,`original_tweet_id`, `reply_to_tweet_id`)
            VALUES ('" . mysqli_real_escape_string($con, $myComment) . "',"
                . $currentUserId . "," . $ogTweetId . "," . $tweetId . ");";
            //echo "your insert:<BR> " . $sql . "<BR>";

        if (!mysqli_query($con, $sql)) $msg = "DATABASE ERROR INSERTING REPLYING! PLEASE CONTACT BITTER SUPPORT!";
        else if (mysqli_affected_rows($con) == 1)  $msg = "REPLY SUCCESSFUL!";
        else $msg = "ERROR INSERTING REPLY! PLEASE CONTACT BITTER SUPPORT!";
        header("location:index.php?message=$msg");    
    }
    public static function timeFromPost($dateAdded){
        date_default_timezone_set("America/Halifax");
        $now = new DateTime();
        $tweetTime = new DateTime($dateAdded);  
        $interval = $now->diff($tweetTime);
 
        if ($interval->y > 1)     return  $interval->format("%y years") . " ago";
        elseif ($interval->y > 0) return $interval->format("%y year") . " ago";
        elseif ($interval->m > 1) return $interval->format("%m months") . " ago";
        elseif ($interval->m > 0) return $interval->format("%m month") . " ago";
        elseif ($interval->d > 1) return $interval->format("%d days") . " ago";
        elseif ($interval->d > 0) return $interval->format("%d day") . " ago<BR>";
        elseif ($interval->h > 1) return $interval->format("%h hours") . " ago";
        elseif ($interval->h > 0) return $interval->format("%h hour") . " ago";
        elseif ($interval->i > 1) return $interval->format("%i minutes") . " ago";
        elseif ($interval->i > 0) return $interval->format("%i minute") . " ago";
        elseif ($interval->s > 1) return $interval->format("%s seconds") . " ago";
        elseif ($interval->s > 0) return $interval->format("%s second") . " ago";
        else return "just now";
    }
    
    public function testIfLiked(mysqli $con, $userId){
         $sql = "SELECT COUNT(*) as `total` FROM likes WHERE "
                 . "tweet_id = " . $this->tweetId .
                 " AND user_id = " . $userId;
        if ($result = mysqli_query($con, $sql)) {
            $row = mysqli_fetch_assoc($result);
            $count = $row['total'];
            if ($count == 0) return false;
            else return true;
        } 
        else return false;
    }
    
    public function getLikeCount(mysqli $con){
        $sql = "SELECT COUNT(*) as `total` FROM likes"
                . " WHERE tweet_id = " . $this->tweetId;
        if ($result = mysqli_query($con, $sql)) {
            $row = mysqli_fetch_assoc($result);
            $count = $row['total'];
            if ($count == 0) return false;
            else return true;
        } 
        else return false;
    }
    public function print($con) {
        if ($this->originalTweetId != 0){ //check if retweet
            $reposter = User::getUserByUserId($con, $this->userId);
            $reposterLinkText = substr($reposter->firstName . " " . $reposter->lastName . " @" . $reposter->userName, 0, 25);
            $repostee = User::getUserByTweetId($con, $this->originalTweetId);
            $reposteeText =  substr($repostee->firstName . " " . $repostee->lastName, 0, 15);
            echo '<a href="userpage.php?user_id='.$this->userId.'">'.$reposterLinkText.'</a>  ';
            date_default_timezone_set("America/Halifax");
            echo Tweet::timeFromPost($this->dateAdded) . "<strong> retweeted from $reposteeText </strong><BR>";        
        }
        else { //normal post
            $user = User::getUserByUserId($con, $this->userId);
            $tweetLinkText = substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25);
            echo '<a href = "userpage.php?user_id='.$this->userId.'">'.$tweetLinkText.'</a>'.' ';
            date_default_timezone_set("America/Halifax");
            echo Tweet::timeFromPost($this->dateAdded) . "<BR>";                                       
        }
        echo $this->tweetText . "<BR>";
        echo '<img class="smallicon" src="images/like.ico">';
        echo '<a href="retweet.php?tweetId=' . $this->tweetId . '"><img class="smallicon" src="images/retweet.png"></a>';
        echo '<img data-toggle="modal" data-target="#add_comment_Modal" data-id="' . $this->tweetId .'" style="height: 30px; margin-left: 0.3em;" src="images/reply.png">';
    }
    
    public function printRetweet($con){
            echo "<div style='background-color:#dddddd; padding:0.25em; margin:0.25em;'> ";
            $reposter = User::getUserByUserId($con, $this->userId);
            if ($reposter->profImage!= "") $profile_pic = $reposter->profImage;
            else $profile_pic = "default.jfif";
            echo '<img class="bannericons" src="images/profilepics/'.$profile_pic.'"> ';
            
            $reposterLinkText = substr($reposter->firstName . " " . $reposter->lastName . " @" . $reposter->userName, 0, 25);
            $repostee = User::getUserByTweetId($con, $this->originalTweetId);
            $reposteeText =  substr($repostee->firstName . " " . $repostee->lastName, 0, 15);
            echo '<a href="userpage.php?user_id='.$this->userId.'">'.$reposterLinkText.'</a>  ';
            date_default_timezone_set("America/Halifax");
            echo " retweeted your tweet " . Tweet::timeFromPost($this->dateAdded) . "<BR>";
            $user = User::GetUserByTweetId($con, $this->originalTweetId);
            echo "<strong>Retweeted from " . substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25) . "</strong>";
            echo "<div style='padding-left:1em'>" . $this->tweetText . "</div>";
            echo "</div><hr>"; 
    }
    
        public function printReply($con){
            echo "<div style='background-color:#dddddd; padding:0.25em; margin:0.25em;'> ";
            $replier = User::getUserByUserId($con, $this->userId);
            if ($replier->profImage!= "") $profile_pic = $replier->profImage;
            else $profile_pic = "default.jfif";
            echo '<img class="bannericons" src="images/profilepics/'.$profile_pic.'"> ';
            
            $linkText = substr($replier->firstName . " " . $replier->lastName . " @" . $replier->userName, 0, 25);
            echo '<a href="userpage.php?user_id='.$this->userId.'">'.$linkText.'</a>  ';
            date_default_timezone_set("America/Halifax");
            echo " replied to your tweet " . Tweet::timeFromPost($this->dateAdded) . "<BR>";
            $user = User::GetUserByTweetId($con, $this->replyToTweetId);
            echo "<strong>Replied to " . substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25) . "</strong>";
            echo "<div style='padding-left:1em'>" . $this->tweetText . "</div>";
            echo "</div><hr>"; 
    }
    
    public function __destruct() {
        //nothing for not
    }
    
    public function __get($n){
        return $this->$n;
    }
    public function __set($property, $value){
        $this->$property = $value;
    }
}
