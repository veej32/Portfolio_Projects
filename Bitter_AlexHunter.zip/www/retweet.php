<?php 
include("connect.php"); 
include_once("includes/Tweet.php");
Tweet::retweet($con, $_GET["tweetId"]);
?>