<!--
//"this page will display a list of all recent likes of the current user's tweets<BR>";
//"as well as a list of retweets of a current user's tweets<BR>";
//"this will be similar to https://twitter.com/i/notifications";
-->

<?php
    session_start();
    //redirect user to Login page if not logged in
    if (!isset($_SESSION["SESS_MEMBER_ID"])) {
        header("location:Login.php");
    }
?>
<script src="https://code.jquery.com/jquery-3.3.1.js" ></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<?php include_once("connect.php"); ?>
<?php include_once("Includes/User.php"); ?>
<?php include_once("Includes/Tweet.php"); ?>
<?php include_once("Includes/Message.php"); ?>

<?php include("Includes/GetMessage.php");?>
<?php
    //get user's id to use throughout page
    $id = $_SESSION["SESS_MEMBER_ID"];
?>
 <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <script src="includes/bootstrap.min.js"></script>

<BR><BR>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bitter: Home of internet dopamine.">
    <meta name="author" content="Nick Taggart, nick.taggart@nbcc.ca">
    <link rel="icon" href="favicon.ico">

    <title>Bitter - Social Media for Trolls, Narcissists, Bullies and Presidents.</title>

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">

    <script>
    $(document).ready(function($) {
	//hide the submit button on page load
	$("#button").hide();
	
	$("#message_form").submit(function() {
		//alert("submit form");
		$("#button").hide();
	});
	$("#message").focus( function() {
        //this will "magically" make the textbox have 5 rows and also
		this.attributes["rows"].nodeValue = 5;
		//show the submit button
		$("#button").show();			
	});//end of click event
        $("#to").keydown(//key down event for the user name textbox
            function(event) {
                if (event.keyCode === 13) {
                    //don't do anything if the user types the enter key, it might try to submit the form
                    return false;
                }
            }//end anonymous function
        );//end keydown event
        $("#to").keyup(//key up event for the user name textbox        
        function() {                
            jQuery.get(                        
              "UserSearch_AJAX.php",
                $("#message_form").serializeArray(),
                function(data) {//anonymous function
                    //uncomment this alert for debugging the directMessage_proc.php page
                    //alert(data) ;  //for debugging
                    //clear the users datalist so it starts empty
                    $("#dlUsers").empty();
                    if (data === "undefined") {
                            $("#dlUsers").append("<option value='NO USERS FOUND' label='NO USERS FOUND'></option>");
                    }
                    $.each(data, function(index, element) {
                            //this will loop through the JSON array of users and add them to the select box
                            $("#dlUsers").append("<option value='" + element.username + "' data-toId='" + element.id + "' label='" + element.name + "'></option>");                        
                    });
                },
                //change this to "html" for debugging the UserSearch_AJAX.php page
                "json"
            );                                              
            //make sure the focus stays on the textbox so the user can keep typing
            $("#to").focus();
            return false;
        }    
    );                
    });//end of ready event handler

    </script>

  </head>

  <body>
    <?php include("Includes/header.php"); ?>
    <?php include 'includes/Modals.php'; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                    <div class="mainprofile img-rounded">
                    <div class="bold">
                        <?php //get & display profile information for the user
                            $user = User::getUserByUserId($con, $id);
                            if ($user->profImage!= "") $profile_pic = $user->profImage;
                            else $profile_pic = "default.jfif";
                            $name = $user->firstName . " " . $user->lastName;

                            echo '<img class="bannericons" src="images/profilepics/'.$profile_pic.'">';
                            echo '<a href="userpage.php?user_id='.$id.'">'. $name. '</a><BR></div>';
                            ?>

                    <table>
                        <tr><td>tweets</td><td>following</td><td>followers</td></tr>
                        <tr>
                            <td><?php echo $user->getNumTweets($con)?></td>
                            <td><?php echo $user->getNumFollowing($con)?></td>
                            <td> <?php echo $user->getNumFollowers($con)?>       </td>
                        </tr>
                    </table>
                    <img class="icon" src="images/location_icon.jpg">
                            <?php echo $user->province;?>
                        <div class="bold">Member Since:</div>
                        <div><?php echo date_format(date_create($user->dateAdded), "F jS, Y");?></div>
                    </div><BR><BR>
                    <div class="trending img-rounded">
                        <div class="bold">Trending</div>
                    </div>

            </div>

          <div class="col-sm-6 img-rounded">
              <div style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;' >
                  <h2 align="center">Likes Found:</h2>
                  <hr>
                    <?php     
                    foreach ($user->GetLikes($con) as $like){
                        $like->print($con);
                    } 
                  ?>
              </div>
              <div style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;'>
                  <h2 align="center">Retweets Found:</h2>
                  <hr>
                  <?php 
                  
                    foreach ($user->GetRetweets($con) as $tweet){
                        $tweet->printRetweet($con);
                    } 
                  ?>
              </div>
                <div style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;'>
                  <h2 align="center">Replies Found:</h2>
                  <hr>
                  <?php 
                  
                    foreach ($user->GetReplies($con) as $tweet){
                        $tweet->printReply($con);
                    } 
                  ?>
              </div>
          </div>
            
              
            <div class="col-md-3">
                    <div class="whoToTroll img-rounded">
                    <div class="bold">Who to Troll?<BR></div>
                    <!-- display people you may know here-->
                    <?php  
                        echo
                        User::whoToTroll($con);                             
                    ?>
                    </div><BR>
                    <!--don't need this div for now 
                    <div class="trending img-rounded">
                    © 2021 Bitter
                    </div>-->
            </div>
        </div> <!-- end row -->
    </div><!-- /.container -->

    
  </body>
</html>


