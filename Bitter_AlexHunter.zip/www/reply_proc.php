<?php include("connect.php"); ?>
<?php include("Includes/User.php"); ?>
<?php include("Includes/Tweet.php"); ?>
<?php
if (isset($_POST['id']) && isset($_POST['myComment'])){
    session_start();
    if (!isset($_SESSION['SESS_MEMBER_ID'])){
        header("location:login.php?");  
    }
    
    Tweet::Reply($con, $_POST["myComment"], $_POST["id"]);
}
?>

