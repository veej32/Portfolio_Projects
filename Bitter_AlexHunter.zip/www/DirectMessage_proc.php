<?php include("connect.php"); ?>
<?php include("Includes/User.php"); ?>
<?php include("Includes/Message.php"); ?>
<?php  
    session_start();
    //redirect user if needed
    if (!isset($_SESSION["SESS_MEMBER_ID"])) {
        header("location:Login.php");
    }
    else if (!isset($_POST["to"]) || !isset($_POST["message"])){
        header("location:DirectMessage.php");
    }
    else {
        $to_username = $_POST["to"];
        $to_user = User::getUserByScreenName($con, $to_username, false);
    
        if ($to_user != null){
            $message = $_POST["message"];
            //echo "To: " . $to_user->firstName . " " . $to_user->lastName . "@ " . $to_user->userName . "<BR>";
            //echo "Message: " . $message . "<BR>"; 
            Message::sendMessage($con, $to_user->userId, $message);
        }
        else {
            $msg = "That user does not exist.";
            header("location:DirectMessage.php?message=". $msg);
        }
        
    }


    
?>
