<!DOCTYPE html>
<?php
session_start();
//redirect user to Index page if already logged in
  if (isset($_SESSION["SESS_MEMBER_ID"]))
  {
        header("location:Index.php");
  }
?>
<?php include("Includes/GetMessage.php");?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bitter: Sign Up and scream into the uncaring abyss of the internet today!">
    <meta name="author" content="Alex V.J. Hunter - alex2infinity@gmail.com">
    <link rel="icon" href="favicon.ico">

    <title>Signup - Bitter</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">
	<!-- Bootstrap core JavaScript-->
    <!--<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>-->
    <script type="text/javascript" src="../Includes/jquery-3.3.1.min.js"></script>
    <script src="includes/bootstrap.min.js"></script>
	<script type="text/javascript">
                /*function $(str){
                    return document.getElementById(str);
                }*/
             $isUsernameAvailable = false;
             $isPostalCodeValid = false;
		function validateForm() {
                    try {
                        //alert("validateForm() called"); //debug alert 
                        //alert("Firstname = " + document.getElementById("firstname").value); 
                        //array of invalid input messages
                        messages = [];
                        
                        //Validate that first name is not blank/too long
                        validateGeneral(messages, true, "firstname", "First Name", 50);
                        
                        //Validate that last name is not blank/too long
                        validateGeneral(messages, true, "lastname", "Last Name", 50);
                        
                        //Validate that email is not blank/too long
                        validateGeneral(messages, true, "email", "Email", 100);
                        
                        //check if username available - if it is, validate that it is not blank/too long
                        validateGeneral(messages, true, "username", "Username", 50);
                        if (!$isUsernameAvailable) messages.push("Username unavailable!"); //checkusernameavailable doens't work well in this context. make some global vars 
                         
                        
                        
                        //Validate that the password & confirmation password are not blank/too long.
                        isPasswordGenValid = validateGeneral(messages, true, "password", "Password", 250);
                        isConfirmGenValid =  validateGeneral(messages, true, "confirm", "Confirmation Password", 250);
                        
                        //if both password and confirmation are not blank/too long then validate that they are equal
                        if (isPasswordGenValid && isConfirmGenValid){ 
                            //Validate that password and confirmation are identical
                            password = document.getElementById("password").value;
                            confirm = document.getElementById("confirm").value;
                            if (password !== confirm) {
                                messages.push("Passwords do not match: Please re-enter and confirm the password.");
                                password = "";
                                confirm = "";
                            }     
                        }
                        
                        //Validate that phone number is not blank/too long. If valid, check it is in format (999)999-9999 
                        if (validateGeneral(messages, true, "phone", "Phone", 25)){ 
                            phonePattern = /\(\d{3}\)\d{3}\-\d{4}/; 
                            phone = document.getElementById("phone").value;
                            if (!validateString(phone, phonePattern)) { //executes when phone is not in proper format
                                messages.push("Invalid phone number. Please enter in format: (999)999-9999.");
                                document.getElementById("phone").placeholder = "Enter your phone number - ie: (999)999-9999";
                            }
                        }
                        
                        //Validate that address is not blank/too long  
                        validateGeneral(messages, true, "address", "Address", 200);
                        //Validate that province is not blank/too long - Though not needed yet, this validation may help later development
                        validateGeneral(messages, true, "province", "Province", 50); 
                        
                        //Validate that postal code isn't blank/too long. If valid, validate that it's in format A9A 9A9
                        if (validateGeneral(messages, true, "postalCode", "Postal Code", 7)){
                            postal = document.getElementById("postalCode").value;
                            postalPattern = /[A-Z]\d[A-Z]\s\d[A-Z]\d/;
                            isPostalValid = validateString(postal, postalPattern); 
                            if (!isPostalValid) {
                                messages.push("Postal code invalid: Please enter in format: L9L 9L9.");
                                document.getElementById("postalCode").placeholder = "Enter your postal code - ie L9L 9L9";
                                
                            }
                        }
                        
                        //Validate that url is not too long
                        validateGeneral(messages, false, "url", "Url", 50); 
                        
                        //Validate description
                        validateGeneral(messages, true, "desc", "Description", 160);
                        
                        //Validate that location is not too long
                        validateGeneral(messages, false, "location", "Location", 50);
                        
                        //Create a message to inform user of invalid input details 
                        invalidMsg = "";
                        for (i=0; i<messages.length; i++) {
                            invalidMsg += messages[i] + "\r\n";
                        }
                        
                        //Evaluate if form is valid
                        if (invalidMsg !== "") { //Executes when there are invalid inputs
                            alert(invalidMsg); //Show user invalid inputs
                            return false; //Prevent form submission
                        }
                        else { //Executs when the form is valid
                            //alert("Form is valid!");
                            return true; //Allow form submission
                        }
                        
                    }
                    catch (ex){ //Display any exceptions for debugging/user feedback
                        /*if (ex.line) line = ex.line; //checking which way to get error's line number
                        else line = ex.stack;
                        alert("CLIENT-SIDE VALIDATION ERROR! " + ex + "/r/n" + line);
                        console.log("ERROR" + ex + "/r/n" + line + "/r/n");*/
                        alert("CLIENT-SIDE VALIDATION ERROR!"); //less in-depth error message for the user 
                        return false;
                    }
                }
                //takes in a stirng to search and a pattern to check for. Returns true/false
                function validateString(str, pattern){
                    console.log("validateString() called");
                    if (str.search(pattern) === 0) return true;
                    else return false;
                    
                }
                
                function validateGeneral(errList, isRequired, id, displayName, maxLength) {
                    //alert("validateGeneral called");
                    value = document.getElementById(id).value;
                    if (isRequired && value.trim() === "") {
                        document.getElementById(id).value = ""; //for some reason value cannot be used to edit the original text value
                        document.getElementById(id).placeholder = "Enter a valid " + displayName + ". (Not blank/whitespace)";
                        //document.getElementById(id).focus();
                        msg =  displayName + " cannot be blank/whitespace.";
                        errList.push(msg); 
                        return false;
                    }
                    else if (value.length > maxLength){
                        msg = displayName + " cannot be more than " + maxLength + " characters long.";
                        errList.push(msg);
                        return false;
                        
                    } 
                    else return true; 
                }
                    
                function checkUsernameAvailable() { //TODO: integrate into validation
                    try {
                        //alert("Username is: " + $("#username").val());
                        $.get( 
                            "ValidateUsername_proc.php", //where to send to
                            $("#username"),
                            function(data) {
                                //alert(data.valid); 
                                //write the resulting message back to the username span tag
                                if (data.valid == true) {
                                    //alert("username available");
                                    $("#usernameSpan").text("Username available!");
                                    $isUsernameAvailable = true;
                                    return true;
                                }  
                                else {
                                    //alert("username unavailable");
                                    $("#usernameSpan").text("Username Unavailable!");
                                    $isUsernameAvailable = false;
                                    return false;
                                }
                            },
                            
                            "json" //change this to HTML for debugging
                        );

                    }  catch (ex) {
                        if (ex.line) line = ex.line; //checking which way to get error's line number
                        else line = ex.stack;
                        alert("AJAX USERNAME CHECKING ERROR!\r\n" + line);
                        console.log("AJAX USERNAME CHECKING ERROR!\r\n" + line + "\r\n");
                        //alert("AJAX POSTAL CHECKING CHECKING ERROR!"); //basic error message for the user
                        return false;
                    }
                }
                function checkPostalCode() { //TODO: integrate into validation
                    try {
                        //alert("Postal Code is: " + $("#postalCode").val());
                        $.get( 
                            "ValidatePostalCode_proc.php", //where to send to
                            {postalCode: $("#postalCode").val(), province: $("#province").val()},
                            function(data) {
                                //alert(data.msg); 
                                if (data.msg == "valid") {
                                    //$("#postalCodeSpan").text(" Valid");
                                    $("#postalCodeSpan").text(data.msg);
                                    $isPostalCodeValid = true;
                                }
                                else {
                                    //$("#postalCodeSpan").text(" Invalid");
                                    $("#postalCodeSpan").text(data.msg);
                                    
                                    $isPostalCodeValid = false;
                                }
                                return false;
                            },
                            
                            "json" //should be json to retrieve members of data
                        );

                    }
                    catch (ex) {
                        if (ex.line) line = ex.line; //checking which way to get error's line number
                        else line = ex.stack;
                        alert("AJAX POSTAL CODE CHECKING ERROR!\r\n" + line);
                        console.log("AJAX POSTAL CODE CHECKING ERROR!\r\n" + line + "\r\n");
                        //alert("AJAX POSTAL CHECKING CHECKING ERROR!"); //basic error message for the user
                        return false;
                    }
                }
                
	</script>
  </head>

  <body>
  <?php include("Includes/guestheader.php"); ?>
    <div class="container">
		<div class="row">
			
			<div class="main-login main-center">
				<h5>Sign up once and troll as many people as you like!</h5>
					<form method="post" id="registration_form" onsubmit="return validateForm()" action="signup_proc.php">
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">First Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="firstname" id="firstname"  placeholder="Enter your First Name"/>
                                                                        
								</div>
							</div>
						</div>
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Last Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="lastname" id="lastname"  placeholder="Enter your Last Name"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Your Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="email" id="email"  placeholder="Enter your Email"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Screen Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="username" id="username"  onkeyup="checkUsernameAvailable()" placeholder="Enter your Screen Name"/>
                                                                        <span id="usernameSpan"></span>
                                                                </div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="password" class="form-control" required name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="password" class="form-control" required name="confirm" id="confirm"  placeholder="Confirm your Password"/>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Phone Number</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="phone" id="phone"  placeholder="Enter your Phone Number"/>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Address</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="address" id="address"  placeholder="Enter your Address"/>
								</div>
							</div>
						</div>
						
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Province</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<select name="province" onchange="checkPostalCode()" id="province" class="textfield1" required><?php echo $vprovince; ?> 
										<option> </option>
										<option value="British Columbia">British Columbia</option>
										<option value="Alberta">Alberta</option>
										<option value="Saskatchewan">Saskatchewan</option>
										<option value="Manitoba">Manitoba</option>
										<option value="Ontario">Ontario</option>
										<option value="Quebec">Quebec</option>
										<option value="New Brunswick">New Brunswick</option>
										<option value="Prince Edward Island">Prince Edward Island</option>
										<option value="Nova Scotia">Nova Scotia</option>
										<option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
										<option value="Northwest Territories">Northwest Territories</option>
										<option value="Nunavut">Nunavut</option>
										<option value="Yukon">Yukon</option>
									  </select>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Postal Code</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" onkeyup="checkPostalCode()"
                                                                               required name="postalCode" id="postalCode"  placeholder="Enter your Postal Code"/>
                                                                        <span id="postalCodeSpan"></span>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Url</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" name="url" id="url"  placeholder="Enter your URL"/>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Description</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" required name="desc" id="desc"  placeholder="Description of your profile"/>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Location</label>
							<div class="cols-sm-10">
								<div class="input-group">
									
									<input type="text" class="form-control" name="location" id="location"  placeholder="Enter your Location"/>
								</div>
							</div>
						</div>
						
						
						<div class="form-group ">
							<input type="submit" name="button" id="button" value="Register" class="btn btn-primary btn-lg btn-block login-button"/>
							
						</div>
						
					</form>
				</div>
			
		</div> <!-- end row -->
    </div><!-- /.container -->
    
  </body>
</html>