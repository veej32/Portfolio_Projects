<?php
ini_set ("display_errors", 0); //modifies php.ini file from code such that errors are not displayed for this page
error_reporting(E_NOTICE); //changes the error reporting to include runtime notices 
try {
    $fh = fopen("Studentsaldj.txt", "r"); //open file read-only
    if (!mysqli_connect("localhost", "username", "password", "shema")){ //intentional error
        throw new Exception("ERROR CONNECTING TO DATABASE!");
    }
} catch (Exception $ex) {
    //echo "ERROR on line " . $ex->getLine() . " in FILE " . $ex->getFile() . "<BR>";
    //log error in php_error.log
    error_log("ERROR on line " . $ex->getLine() . " in FILE " . $ex->getFile()); 
}
finally {
    //gets here either way
    fclose($fh); //close the file
}

