<!DOCTYPE html>
<link href="../includes/bootstrap.min.css" rel="stylesheet">
<script type="text/javascript" src="../Includes/jquery-3.3.1.min.js"></script>
<script src="../includes/bootstrap.min.js"></script>

<script>
function ValidatePostalCode() { //TODO: integrate into validation
    alert("Province: " + $("#province").val() + "<br>Postal Code: " + ("#postalCode").val() );
    
//        //alert("Username is: " + $("#username").val());
//        $.get( 
//            "ValidateUsername_proc.php", //where to send to
//            $("#username"),
//            function(data) {
//                //alert(data.valid); 
//                //write the resulting message back to the username span tag
//                if (data.valid == true) {
//                    //alert("username available");
//                    $("#usernameSpan").text("Username available!");
//                    $isUsernameAvailable = true;
//                    return true;
//                }  
//                else {
//                    //alert("username unavailable");
//                    $("#usernameSpan").text("Username Unavailable!");
//                    $isUsernameAvailable = false;
//                    return false;
//                }
//            },
//
//            "json" //change this to HTML for debugging
//        );
</script>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Fedex postal code test</title>
    </head>
    <body>
        <form action="fedex">
            <input type="text" name="postalCode" id="postalCode"><BR>
            <select name="province" id="province" class="textfield1" required>
                <option> </option>
                <option value="British Columbia">British Columbia</option>
                <option value="Alberta">Alberta</option>
                <option value="Saskatchewan">Saskatchewan</option>
                <option value="Manitoba">Manitoba</option>
                <option value="Ontario">Ontario</option>
                <option value="Quebec">Quebec</option>
                <option value="New Brunswick">New Brunswick</option>
                <option value="Prince Edward Island">Prince Edward Island</option>
                <option value="Nova Scotia">Nova Scotia</option>
                <option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
                <option value="Northwest Territories">Northwest Territories</option>
                <option value="Nunavut">Nunavut</option>
                <option value="Yukon">Yukon</option>
            </select><BR>
            <input type="submit" name="submit" id="submit"><BR>
            
        </form>
    </body>
    

