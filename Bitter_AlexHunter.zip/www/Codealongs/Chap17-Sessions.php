<?php
//Internet is stateless - each request is completely separate and doen't know about any others
session_start(); // USE EVERY TIME U WANT TO USE SESSION VARIABLES
echo session_id() . " MY SESSION ID<BR>"; //UNIQUE TO EACH USER
$_SESSION["name"] = 'Alex'; //like sprint 2 on login_proc.php
$_SESSION["age"] = 21; //like sprint 2 on login_proc.php
echo $_SESSION["name"] . "<BR>";
//default session timeout is 20m

echo session_encode() . "ALL MY SESSION VARIABLES<BR>";
echo session_decode(session_encode()) . "<BR>";

//could be used to logout

//session_unset();    //removes all session variables but keeps id
//session_destroy(); //kill session
//redirect them to login.php with header(location line)
header("location:../Login.php")
//echo session_encode() . " ALL MY VARIABLES"; //returns an error, as there is no session to encode/display

?>