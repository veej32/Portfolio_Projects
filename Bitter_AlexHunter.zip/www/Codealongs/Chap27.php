<!DOCTYPE html>
<?php
if (isset ($_GET["message"])) {
    $message = $_GET["message"];
    echo "<script>alert('$message')</script>";
}
?>
<html>
    <head>
        <!-- Don't worry about the HTML specifics, this is a PHP course-->
    </head>    
    <body>
        <!--method="get" is the default -->
        <form method="post" action="Chap27_proc.php">
            <!--when the user submits this form, it will go to chap27_proc.php -->
            <label>Name:</label><input type="text" name="txtName"><br>
            <label>Email: </label><input type="email" name="txtEmail"><br>
            <!--<label>ID: </label><input type="id" name="txtId"><br>-->
            <input type="submit">            
        </form>        
    </body>
</html>