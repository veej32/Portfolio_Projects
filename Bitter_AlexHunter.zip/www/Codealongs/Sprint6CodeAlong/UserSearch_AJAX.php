<?php
    //this is for sprint 6
    //we'll finish writing this code in class
    $screenName = $_GET["to"]; //grab whatever the user typed
    $userId = 22; // $_SESSION["SESS_MEMBER_ID"];
    GetUsers($screenName, $userId);
    

function GetUsers($screenName, $userId) {
    //run a DB query to retriev the users matching given screen name
    //Join with the follows tbale to get only that they follow
    //$sql = "select * from users where screen_name like '%$screenName%'
    // inner join follows f on f.from_id = u.user_id;
    //put this in funciton of your users class 
    //loop through the results and build an array
    //json_encode the resulting array and return it
    
    //it will do this for each new letter typed

    
    if (true) { //if there are results
        $userList[0] = array('id'=>333, 'name'=>"Alex Hunter", 'username'=>"alexHunter");
        $userList[1] = array('id'=>343, 'name'=>"John Smith", 'username'=>"johnsmith");
        $userList[2] = array('id'=>564, 'name'=>"Bob Ross", 'username'=>"bobross");
        $json_data = json_encode($userList);
        echo $json_data;
    }
    else {
        //when no results are returned
        echo "NO USERS FOUND!";
    }
    
    
}

?>