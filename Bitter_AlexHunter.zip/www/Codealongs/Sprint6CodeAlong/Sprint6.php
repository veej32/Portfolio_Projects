<?php
session_start();

?>
<script src="https://code.jquery.com/jquery-3.3.1.js" ></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
$(document).ready(function() {
	//hide the submit button on page load
	$("#button").hide();
	
	$("#message_form").submit(function() {
		//alert("submit form");
		$("#button").hide();
	});
	$("#message").focus( function() {
        //this will "magically" make the textbox have 5 rows and also
		this.attributes["rows"].nodeValue = 5;
		//show the submit button
		$("#button").show();			
	});//end of click event
        $("#to").keydown(//key down event for the user name textbox
        function(event) {
            if (event.keyCode === 13) {
                //don't do anything if the user types the enter key, it might try to submit the form
                return false;
            }
        }//end anonymous function
        );//end keydown event
        $("#to").keyup(//key up event for the user name textbox        
        function() {                
            jQuery.get(                        
              "UserSearch_AJAX.php",
                $("#message_form").serializeArray(),
                function(data) {//anonymous function
                    //uncomment this alert for debugging the directMessage_proc.php page
                    //alert(data);  //for debugging
                    //clear the users datalist so it starts empty
                    $("#dlUsers").empty();
                    if (data === "undefined") {
                            $("#dlUsers").append("<option value='NO USERS FOUND' label='NO USERS FOUND'></option>");
                    }
                    $.each(data, function(index, element) {
                            //this will loop through the JSON array of users and add them to the select box
                            $("#dlUsers").append("<option value='" + element.username + "' data-toId='" + element.id + "' label='" + element.name + "'></option>");                        
                    });
                },
                //change this to "html" for debugging the UserSearch_AJAX.php page
                "json"
            );                                              
//make sure the focus stays on the textbox so the user can keep typing
$("#to").focus();
return false;
}    
);                
});//end of ready event handler
	    
</script>


<form method="post" id="message_form" action="DirectMessage_proc.php">
    <div class="form-group">
		Send message to: <input type="text" id="to" name="to" list="dlUsers" autocomplete="off"><br>
		<datalist id="dlUsers">
			<!-- this datalist is empty initially but will hold the list of users to select as the user is typing -->
		</datalist>
		                           
		<textarea class="form-control" name="message" id="message" rows="1" placeholder="Enter your message here"></textarea>
		<input type="submit" name="button" id="button" value="Send" class="btn btn-primary btn-lg btn-block login-button"/>
	</div>
</form>