<?php
//chap 15 file uploads (used for upload photoss sprint #3)
if (isset ($_GET["msg"])) {
    $message = $_GET["msg"];
    echo "<script>alert('$message')</script>";
}
?>
<form action = "Chap15_proc.php" method="post" enctype="multipart/form-data" ><!--<!-- important for images -->
    Please select your image (must be under 5MB):<br>
    <input type="file" accept="image/*" name="photo" required="required"><br><!--accept limits search to a certain type of file, in this case and image of any type /*-->
    <input type="submit" name="submit" value="UPLOAD">
    
</form>

