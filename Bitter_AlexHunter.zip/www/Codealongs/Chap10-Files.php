<?php
//absolute path
echo "absolute path <BR><BR>";
$filePath = "d:/php/students.txt";
printf("the size of the file is %s bytes<BR>", filesize($filePath)); //printf is print formated
printf("the name of the file is %s <BR>", basename($filePath)); //just file name
printf("the directory path is %s <BR>", dirname($filePath));

//relative path
echo "<BR><hr> relative path <BR><BR>";
$relPath = "../Images/lightning.png";
printf("the size of the file is %s kilobytes <BR>", round(filesize($relPath)/1024, 2));
echo "absolute path " . realpath($relPath) . "<BR>";
printf("Disk space total: %s megabytes<BR>", round(disk_total_space("d:")/1024000, 1));
printf("Disk space remaining: %s megabytes<BR>", round(disk_free_space("d:")/1024000, 1));

//open the file
//r means read-only 
//w means write 
//x means create 
//w+ means read+write 
//a means append
//a+ means append + write
$myFile = fopen($filePath, "a+");
fwrite($myFile, "nick\r\n");
rewind($myFile); //go to start of file
fwrite($myFile, "STARTER\r\n");
rewind($myFile); //go to start of file
while (!feof($myFile)){
    echo fgets($myFile) . "<BR>";
}//end file
fclose($myFile);



