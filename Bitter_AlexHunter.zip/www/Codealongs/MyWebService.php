<?php
//a web service is a way to expose data and or functionality to outside programmers/systems

//let's convert celsius to farenheight
$celsius = $_GET["celsius"]; //get the variable from the URL querystring
$result = $celsius * 1.8 + 32; //get the fahrenheit value

if (isset($_GET["format"])) $format = $_GET["format"];
else $format = ""; 

if ($format == "json"){
    header("content-type: application/json");
    echo json_encode(array("value"=>$result));
}
else { //xml/default
    header("content-type: text\xml");
    echo "<?xml version=\"1.0\"?>";
    echo "<root>";
    echo "<value>" . $result . "</value>";
    echo "</root>";
}//end if

//we did the calculation, but how do we send it?
// XML is one way to format the data to return it
// or JSON (JavasScript Object Notation)

