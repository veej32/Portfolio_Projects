<?php 

if (isset($_POST["submit"])){//user can't get here directly by typing it into their browser
    //attempt to upload the file
    if (empty($_FILES["photo"])){
        $message = "Please upload a profile picture.";
    }
    echo "THE FILE SIZE IS: " . $_FILES['photo']['size'] . "<BR>";
    echo "THE FILE NAME IS: " . $_FILES['photo']['tmp_name'] . "<BR>";
    //print_r($_FILES);
    $MAX_FILE_SIZE = 5 * 1025 * 1024; //5MB
    if ($_FILES['photo']['size'] > $MAX_FILE_SIZE) {
        $message = "File must be less than 5MB!";
        unlink($_FILES['photo']['tmp_name']); //delete the file
    } 
    else {
        $destFile = "../images/profilepics/" . $_FILES['photo']['name']; 
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $destFile)){ //in a real application you need a unique name rather than using the tmp_name.
            $message = "SUCCESS!";
        }
        else {
            $message = "ERROR<BR>";
            unlink($FILES['photo']['tmp_name']);
        }
    }
}//end if
//update the profile_pic of the users table for this user.
echo $message;
//header("location:Chap15-uploads.php?msg=$message");
