<?php include("../connect.php"); ?>
<?php
    if (isset($_POST["txtName"])){ 
        //process the form
        //Will only get here if the user submitted a form via post with something in txtName
        $name = $_POST["txtName"]; //set name to form field named txtName
        $email = $_POST["txtEmail"];
        //$id = $_POST["txtId"];
        echo $name . " " . $email . "<BR>";
        //now we could insert into a database or something
        
        //select statement
        $id = 1;
        $sql = "select * from products where ID = $id";
        if ($result = mysqli_query($con, $sql)){ //$con is global var from connect.php
            while ($row = mysqli_fetch_array($result)){
            echo $row["ID"] . " " . $row["Category"] . " " . $row["Description"] . "<BR>";
           }
        }
        
        //insert statement
        $prodId = 444;
        $desc = "Hockey stick";
        $category = "Sportswear";
        $price = 49.99;
        $sql = "INSERT INTO `productsdemo`.`products` "
        
    . "(`ID`,`Category`,`Description`,`Image`,`Price`) VALUES " 
    . "('$prodId', '$category', '$desc', '', $price)"; //sql requires single quotes around strings
    echo $sql . " debugging<BR>";       
        mysqli_query($con, $sql); //run the sql statment
        //check to make sure that the insert worked.
        if (mysqli_affected_rows($con) == 1) {
            $msg = "INSERT SUCCESSFUL - ";
        }
        else {
            $msg = "ERROR ON INSERT - ";
        }
        
        //update statement
        $desc = "baseball bat"; 
        $sql = "update 'productsdemo'.'products' set 'Description' = '$desc' "
                . "where ID = 444";
        
echo $sql ." <BR>Update STATEMENT<BR>";
     mysqli_query($con, $sql);
             if (mysqli_affected_rows($con) == 1) {
            $msg = "UPDATE SUCCESSFUL";
        }
        else {
            $msg = "ERROR ON UPDATE";
        }
    }//end if
    //? means the data is on the URL querystring
    //send the user somewhere else using a header redirect
    header("location:chap27.php?message=$msg");
?>

