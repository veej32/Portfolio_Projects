<?php
//associative array of username/password combinations
$valid_passwords = array ("jimmy" => "opensesame");  //jimmy is the key to opensesame.
$valid_users = array_keys($valid_passwords); //just grab the keys from the key-value pair

//this is really unprofessional, showing errors even before user logs in!
$user = $_SERVER['PHP_AUTH_USER'];  //check if the user has entered a username yet
$pass = $_SERVER['PHP_AUTH_PW'];    //check for a password

// validate: check if $user key is in  array and check if value of the $user key is the $pass variable
$validated = (in_array($user, $valid_users)) && ($pass == $valid_passwords[$user]); //if $user not in array, second condition won't execute (would cause error)

if (!$validated) { //if not validated, send a 401 HTTP response to prompt them //look at this a bit more in book to understand
  header('WWW-Authenticate: Basic realm="My Realm"');
  header('HTTP/1.0 401 Unauthorized');
  die ("Not authorized"); //kill session
}

    // If arrives here, is a valid user.
    echo "<p>Welcome $user.</p>";
    echo "<p>congrats, you are into the system.</p>";




//HINT for sprint #3
//imagine this is on signup_proc.php
$myPassword = "opensesame";
$myHashedPassword = password_hash($myPassword, PASSWORD_DEFAULT); //one-way encryption algorithm
echo $myHashedPassword . " hashed password to insert into users table of the DB<BR>";

//this will go in login_proc.php
//returns 1 if password matches the hash, null if not
echo password_verify("opensesame", $myHashedPassword); // don't ask questions  
?>