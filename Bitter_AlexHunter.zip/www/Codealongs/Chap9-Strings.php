<?php include "../connect.php"; ?>
<?php
function p($myString) {
    echo $myString . "<BR>";
}

//PREG = Perl-compatible regular expressions
$students = array("Nick", "Jimmy", "Johnny", "jill");
$foundStudents = preg_grep("/J/i", $students); //returns an array of matching eleements. slash begins and ends a regex pattern
print_r($foundStudents);
echo "<BR>";

$myString = "Johnny Johnson"; 
print_r(preg_match_all("/John/", $myString)); //returns total number of matches in the string
echo "<BR>";

$myString = "$***999.34";
p(preg_quote($myString)); //adds backslash/escape character to certian characters (non-digits/letters)

$myString = "have your cake and cake eat it too";
$newString = preg_replace("/cake/", "apple", $myString); //tries to replace pattern with string, returns OG string if not fount
//$newerString = preg_replace("/it/", "them", $newString);
p($newString);

$newString = preg_filter("/HELLO/", "apple", $myString); //doesnt return anything because HELLO is not found if it was found, it would return the string
p($newString);

$myString = "have your cake and eat it too";

$myArray = preg_split("/ /", $myString);
print_r($myArray);


p(strlen($myString)); // get the length of the string
$string2 = "Hello";
$string1 = "HELLO";

p('INDEX OF strcasecmp search ' .strcasecmp($string2, $string1)); //string comparison. if result is 0, they are equal

p(strtolower($string2)); //convert string to lower case
p(ucfirst($string2));   //makes the first letter capitalized/upper case

$myString = "Café Français + & ^ % $ ©";
p(htmlentities($myString)); //turns them into appropriate html entities

$myString = "O'henry";
echo addslashes($myString); //ads \ before everything that needs it

//HINT FOR SPRINT #3

//mysqli_real_escape_string($con, $myString);
echo "<BR>";
$myString = "PHP <BR> is <BR> <b>cool</b>";
p($myString);

//imagine if u could name yourself this on facebook lmao
$myInjection = "<script>alert('ok so I am ultimately PISSED OFF RIGHT NOW because my STUPID INSENSITIVE BIGOT OF A SCIENCE TEACHER WONT COVER THE SKELETON IN OUR CLASSROOM!!!! ive told him THOUSANDS of TIMES that i have severe anxiety from sans and ive actually developed ptsd from the sans fight and i have to carry an inhaler everywhere i go now because when i see bones or the color blue i start hyperventilating because of panic then if I don\’t take my inhaler it turns into a ptsd episode and i already had to be sent home 3 TIMES BECAUSE THE SKELETON IN MY SCIENCE CLASS TRIGGERED ME!!!! AND HE WONT COVER IT!!!!!!! like????? i dont know what to do ive tried talking about it to the councilor but they said my condition isnt real???? like um YEAH IT IS??? i would know??????????? cause I wake up screaming and in tears each night because i have a recurring nightmare where SANS TELLS ME IM GOING TO HAVE A BAD TIME THEN HAS THE FUCKING DECENCY TO TO TELL ME IVE DIED 10 TIMES, AND THAT I HAVE NO FRIENDS!!!! YOU KNOW HOW MUCH THAT FUCKING TRIGGERS ME???????? and it just PISSES ME OFF how the school CARE THST I AM ON THR BRINK OF OFING BECAUSE OF THIS!!!!!!!!!')</script>"; //imagin if your name yourself this on facebook. everyone who sees your name is going to have a bad time
p($myInjection);

p(strip_tags($myString));