<?php

$format = "json";//try JSON later
$temp = 100;
$url = "http://localhost/Codealongs/MyWebService.php?celsius=" . $temp . "&format=".$format;

//curl is a versatile set of libraries that allow php to send/recieve http data.
//curl stands for client URL
//Amazon Web Services uses web services, and so does google
$cobj = curl_init($url); //initialize curl session ;3

//we want data to come back rather than displaying on screen
curl_setopt($cobj, CURLOPT_RETURNTRANSFER, 1);
$data = curl_exec($cobj);

if ($format == "xml") {
    $xmlObject = simplexml_load_string($data); //loads the well-formatted XML document into an object
    echo "the value in fahrenheit is: " . $xmlObject->value;
}
else { // json
    $object = array(json_decode($data));
    echo "Value in fahrenheit: " . $object[0]->{"value"};
    //echo var_dump($object); //just for debugging - might let people see sensitive info
}
