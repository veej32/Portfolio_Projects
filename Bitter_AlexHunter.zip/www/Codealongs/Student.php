<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Student
 * @author alex2
 */
class Student {
    private $name;
    private $address;
    protected $age; //accessible in any subclasses
    //chap 7 covers inheritance but we're not going to do it.
    CONST SCHOOL = "NBCC"; //cant be overiden and doesn't use $
    
    public static $numCourses; //same for all instances of the object;
    
    public static function DoSomething() {
        echo "INSIDE STATIC FUNCTION<BR>";
    }
    //can only exist in abstract classes & be used by inherited classes
    //public abstract function SomeFunction(); //no body because abstract -
    
    public final function MyFinalMethod() {
        echo "function can't be overriden";
    }
    
    public function __construct($name, $address, $age) {
        $this->name = $name;
        $this->address = $address;
        $this->age = $age;
    }
    
    public function __destruct() {
        echo "ENTERING DESTRUCTOR"; //useful to free up space
    }
    
    public function __get($n){
        return $this->$n;
    }
    public function __set($property, $value){
        $this->$property = $value;
    }
    
    
//    public function GetName() {
//        //$this is a reference to current object
//        //-> dereference the pointer (same usage as "." in java)
//        return $this->$name;
//    }
//    public function SetName($n){
//        $this->$name = $n;
//    }
}
