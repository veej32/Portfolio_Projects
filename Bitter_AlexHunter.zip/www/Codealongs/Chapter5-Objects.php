<?php
include("Student.php"); //include the file that has the class
$s = new Student("Jimmy", "123 Mian st", 17);

Student::$numCourses = 8;
echo Student::$numCourses . "<BR>"; //call static property
Student::DoSomething();

PrintDetails($s);

function PrintDetails(Student $s){
    echo $s->name . " - Address: " . $s->address . " Age: " . $s->age . "<BR>";
}