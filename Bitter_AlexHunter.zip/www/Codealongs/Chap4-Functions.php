<?php
function MultiplyNumbers(int $x, int $y) {
    return $x * $y;
}
function Dice($x){
    return rand(1, $x);
}

function PrintMessage(&$x){ //& means it is passed by REFERENCE, turning 'Hello World' into 'Bonjour monde".
    $x = "Bonjour monde.";
    echo $x . "<BR>";
    //doesnt return anything, 
}

//function factorial($n) {//5! = 5 x 4 x 3 x 2 x 1
//    $result = 1; 
//    for ($i = $n; $i > 0; $i--){
//        $result *= $n;
//    }
//    return $result;
//}

//recursive function
function factorial($n){ //solving the factorial using recursion
return ($n == 1) ? 1 : $n * factorial($n-1); 
//    if ($n == 1) return 1;
//    else {
//        return $n * factorial($n-1);
//    }
}

//get a random number
echo Dice(6) . "<BR>";
echo getrandmax() . "<BR>";
echo MultiplyNumbers(Dice(6),3.14) . "<BR>";

$message = "Hello world";
PrintMessage($message); //passes by reference & changes value, soo....
echo $message . " MESSAGE<BR>";//this is changed too!

echo factorial(6) . "<BR>";
//echo (1 == 1) ? "TRUE" : "False";
?>

