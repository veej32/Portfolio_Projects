<?php
$valid = checkdate(1, 31, 2021); //return 1 if valid date, else null
echo $valid . "<BR>";

setlocale(LC_ALL, "can-EN"); //"can-EN" is canadian english; "can-FR" is canadian french

//%A means day of the week
//%d = day of the month
//%F = full date
//%B = month
//%Y = year
echo strftime("%A, %B %d, %Y") . "<BR>";
echo date ("F d, Y") . "<BR>";
//TIMES!!!!
date_default_timezone_set("America/Halifax");
echo date("h:i:sA") . "<BR>";
print_r(getDate() );
echo "<BR>";
echo "page was last modified on " . date("F d, Y h:i:sA", getlastmod()) . "<br>";

$dateTweeted = "2021-10-12 14:50:00"; //in sprint # this will come from the tweets table of the DB
    
$now = new DateTime();// defaults to current date time

$tweetTime = new DateTime($dateTweeted); //convert string to a date
$interval = $now->diff($tweetTime);
echo $interval->format("%y %d %h %i %s") . " interval <BR>";
if ($interval->y > 1) echo $interval->format("%y years") . " ago<BR>";
elseif ($interval->y > 0) echo $interval->format("%y year") . " ago<BR>";
elseif ($interval->m > 1) echo $interval->format("%m months") . " ago<BR>";
elseif ($interval->m > 0) echo $interval->format("%m month") . " ago<BR>";
elseif ($interval->d > 1) echo $interval->format("%d days") . " ago<BR>";
elseif ($interval->d > 0) echo $interval->format("%d day") . " ago<BR>";
elseif ($interval->h > 1) echo $interval->format("%h hours") . " ago<BR>";
elseif ($interval->h > 0) echo $interval->format("%h hour") . " ago<BR>";
elseif ($interval->i > 1) echo $interval->format("%i minutes") . " ago<BR>";
elseif ($interval->i > 0) echo $interval->format("%i minute") . " ago<BR>";
elseif ($interval->s > 1) echo $interval->format("%s seconds") . " ago<BR>";
elseif ($interval->s > 0) echo $interval->format("%s second") . " ago<BR>";