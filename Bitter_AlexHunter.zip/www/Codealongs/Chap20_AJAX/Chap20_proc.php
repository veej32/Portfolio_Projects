<?php include("../../connect.php"); //you may need to change this - nope it works for me?>
<?php
//put logic here to query the Users table of the DB and check if the username already exists
//if (isset($_GET("txtUsername"))){
    $username = $_GET["txtUsername"];

    $strSql = "select * from users where screen_name='$username'";
    $json_out = '{"msg":"Something went wrong!"}';
    //echo $username;
    //echo $strSql;
    if ($result = mysqli_query($con, $strSql)){
        //executes when their is one or more records retrieved from database
        if (mysqli_num_rows($result) > 0 ){
            //user NEVER sees this page, and echoing is used for json return data
            //$json_out is just the variable of the string 
            $json_out = '{"msg":"Sorry, username is already taken. Please try again."}'; //inside the array you need double quotes!
        } 
        else {
            $json_out = '{"msg":"Username is available!"}';
        } //end else
    }
    echo $json_out;
//}
?>