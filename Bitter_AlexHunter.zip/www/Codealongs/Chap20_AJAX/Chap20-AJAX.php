<?php
//Chapter 20 - AJAX (Asychronous JavaScript and XML)
?>
<html>
    <head>
        <title>Chap 20-AJAX</title>
        <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
        <script>
            //just a little jquery for an AJAX technique
            function SubmitForm(){
                $.get(
                    "Chap20_proc.php", //where you want to submit too
                    $("#myForm").serializeArray(),  //what data you send (in this case, serialized string format to be able to get form elements via $_GET[name]
                    function(data) {//anonymous function that processes string data returned. I returned a key-value array formated like: {"msg":msgValue}
                        //alert(data); //use this for debugging
                        //write the resulting message back to the mySpan tag
                      $("#mySpan").text(data.msg);  //sets span element to the 
                    },
                    //standard communication method
                    "json" //you can change this to HTML for debugging(alerts/text) but it will lose some funcitonality
                );
        
                return true;
            }
        </script>        
    </head>
    <body>
        <!-- the world's simplest form -->        
        <form method="get" id="myForm"  action="SomePage_proc.php">
            Username:<input type="text" onkeyup="SubmitForm()" name="txtUsername" >
            <span id="mySpan"></span><!-- Display messages in this SPAN--><BR>
            Password:<input type="password" name="txtPassword"><BR>
            First Name:<input type="text" name="txtFirstName"><BR>
            Last Name:<input type="text" name="txtLastName"><BR>
            Address:<input type="text" name="txtAddress"><BR>
            City:<input type="text" name="txtCity"><BR>
            Postal Code:<input type="text" name="txtPostalCode"><BR>
            <input type="submit" value="Create Account" >
        </form>        
    </body>        
</html>