<?php
$url = "api.openweathermap.org/data/2.5/weather?q=Fredericton&units=metric&APPID=45bfb762ed60106a45fd68fdcc0848fa";
$client = curl_init($url);
curl_setopt($client, CURLOPT_RETURNTRANSFER, 1); //return the data, NOT display on the screen
$data = curl_exec($client);
curl_close($client); //don't forget to close connection :/

//echo $data;

$myArray = json_decode($data); //turn json string into a string

foreach($myArray as $t) {
    
    print_r($t);
    echo "<BR>";
}
echo "<BR>";
//print array lets you see everything, including members of objects
print_r($myArray);

echo "<BR><BR>";
echo $myArray->coord->lon . "<BR>";
echo $myArray->coord->lat . "<BR>";
echo $myArray->weather[0]->description . "<BR>";
echo $myArray->main->temp. "<BR>";

