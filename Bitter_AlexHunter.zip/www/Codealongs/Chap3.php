<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Chapter 3</title>
    </head>
    <body>
        <?php
        // comment
        /*
         * multiline comment
         */
        //all vars must begin with $
        $myName = "Alex"; //string
        $age = 50.5;
        echo "Your name is " . $myName . "<BR>"; //string concatenation is a dot :o
        echo "age is " . ++$age . "<BR>";
        $x = "y";
        $y = "x";
        echo $y . "<BR>"; //prints x
        //might be a multiple-choice in midterm
        echo $$y . "<BR>"; //prints $x aka y 
        print("HELLO WORLD<BR>");
        printf ("Hello world %s<BR>", $myName); //%s is placeholder for a variable
        $value = (bool) true;
        $value = 'HELLO WORLD';
        $value = 0755; //octal
        $value = 0x1000; //hexadecimal
        
        echo "VALUE " . $value . "<BR>";
        
        //arrays are covered in chapter 5
        $grades[0] = 100;
        $grades[1] = 98;
        //php is case-sensitive
        $AGE = 100; //this is technically allowed but looks dumb
        $x = "5";
        $y = "10";
        //type juggling can be confusing
        echo "TOTAL:    " . ($x + $y) . "<BR>";
        //echo gettype($x);
        const SPEED_OF_LIGHT = 300000000; //no $
        //byref variables
        echo "you can declare variables by ref (meaning they have same value as another)<BR>";
        $x =& $y;
        $y = 500;
        echo $x . " BYREF<BR>";
        if ($x === "500") { //=== means has same data and type
            echo "EQUAL AND OF SAME TYPE<BR>";
        }
        elseif ($x == "500") { //== means has same type
            echo "EQUAL, BUT NOT SAME TYPE!<BR>";
        }
        elseif ($x > $y) { //elseif is all one word in php
            echo "GREATER  THAN<BR>";
        }
        else {
            echo "LESS THAN<BR>";
        }
        echo "<BR>echo (\$x <=> \"500\") //the spaceship operator compares 2 values and returns -1 if less than, 0 if equal, and 1 if greater than<BR>" ;
        echo "Result: " . ($x <=> "500") . "<BR><BR>"; //spaceship operator. if i had the right php version than it would say if it is less than, greater than or less than
        
        //for loop
        for ($i = 0; $i<10; $i++){
            if ($i == 5) break; 
            echo $i . "<BR>";
            //break exits loop, continue just skips current iteration
        }
        
        do {
            echo pow($i, 2) . "<BR>"; //$i to power of 2
            $i++; //infinite loop if u forget this
        } while ($i<10);
        
        //$myName = "Alex";
        ?>
        
        <!-- this is a short circuit tag. It's a shortcut for echoing a PHP variable-->
        <p>This is a sentence with my name: My name is <?=$myName?>.</p>
        
    </body>
</html>
