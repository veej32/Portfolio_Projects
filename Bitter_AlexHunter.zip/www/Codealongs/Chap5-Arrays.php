<?php

//$numbers[0] = 5; //an array
//$numbers[1] = 8;
//$numbers[2] = 9;

$numbers = [3 => 5,8,9]; //associative array that begins at index 3.
print_r($numbers);

$populations = ["Fredericton" => 60000, "Saint John" => 70000, "Moncton" => 80000];
//print_r($populations);

//2d array
$twoDArray = array("Jimmy" => array(99,88,77),
                    "Johnny" => array(55,66,77),
                    "Susie" => array(88,99,66));

echo $twoDArray["Johnny"][2];

foreach($twoDArray as $student) //student represents the element in twoDArray.
{
    echo $student[0] . " " . $student[1] . " " . $student[2] . "<BR>";
}//end foreach
echo count($twoDArray) . "<BR>"; //how many elements in your array? 3 arrays!
echo sizeof($twoDArray) . "<BR>"; //same thing as count


$myNums = range("1", "100"); //range(1,100)
print_r(array_reverse($myNums));

$students = file("students.txt"); //open the file 
foreach ($students as $student){
    echo $student . "<BR>";
    list($name, $city, $grade) = explode("|",$student);
    echo $name . " " . $city . " " . $grade . "<BR>";
}

array_unshift($myNums, 999); //add to the beginning of the array (element goes at begining and rest shift right
array_push($myNums, 500); // add to the end of the array
array_shift($myNums); //remove from beginning of array
array_pop($myNums); //remove from end of array

//searching! - looks at values, NOT KEYS
//BUT you can use flip_array to flip keys and values :)
/*$populations = array_flip($populations); //flip it
if (in_array("Fredericton", $populations)) {
    echo "FOUND<BR>";
    
}
else { echo "NOT FOUND<BR>"; }
print_r($myNums); */
sort($populations);
$newArray = array("test1", "test2", "Test10", "test10", "test22");
//sort($newArray, SORT_NATURAL);
natcasesort($newArray); //makes sort case-insensitive 
echo "<BR><BR>";
$mergedArray = array_merge($myNums, $newArray);
print_r($mergedArray);

print_r($newArray);

    

?> 

