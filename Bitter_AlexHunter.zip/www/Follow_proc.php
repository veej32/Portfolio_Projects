<?php include("connect.php"); ?>
<?php include_once("Includes/User.php"); ?>
<?php
//this page will be used when the user clicks on the "follow" button for a particular user
//process the transaction and insert a record into the database, then redirect the user back
// to index.php

session_start();
$followerId = $_SESSION['SESS_MEMBER_ID'];
$followeeId = $_GET['user_id'];
User::follow($con, $followerId, $followeeId);
?>