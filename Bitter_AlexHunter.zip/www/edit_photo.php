<?php
    session_start();
    //redirect user to Login page if not logged in
    if (!isset($_SESSION["SESS_MEMBER_ID"])) {
        header("location:Login.php");
    }
?>
<?php include_once("connect.php"); ?>
<?php include("Includes/GetMessage.php");?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bitter: Edit your profile picture to something less embarrassing!.>
    <meta name="author" content="Alex Hunter">
    <link rel="icon" href="favicon.ico">

    <title>Edit Photo - Bitter</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">
	<!-- Bootstrap core JavaScript-->
    <!--<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>-->
    <script type="text/javascript" src="Includes/jquery-3.3.1.min.js"></script>
    <script src="includes/bootstrap.min.js"></script>
	
	
  </head>

  <body>
    <?php include("Includes/header.php"); ?>
    <div class="container">
		<div class="row">
			
			<div class="main-login main-center">
				<h5>Edit your profile picture here!</h5>
					<form method="post" id="edit_photo_form" action="edit_photo_proc.php" enctype="multipart/form-data" >
						
						<div class="form-group img-rounded">
							<label for="name" class="cols-sm-2 control-label">(Must be under 5 megabytes)</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<input type="file" accept="image/*" name="photo" required="required">
                                                                        
								</div>
							</div>
						</div>
						
						
						<div class="form-group ">
							<input type="submit" name="upload_picture" id="button" value="Upload!" class="btn btn-primary btn-lg btn-block login-button"/>
							
						</div>
						
					</form>
				</div>
			
		</div> <!-- end row -->
    </div><!-- /.container -->
    
  </body>
</html>
  </body>
</html>
