-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2021 at 08:21 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bitter-alexhunter`
--
CREATE DATABASE IF NOT EXISTS `bitter-alexhunter` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bitter-alexhunter`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `follows`
--

DROP TABLE IF EXISTS `follows`;
CREATE TABLE IF NOT EXISTS `follows` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `FK_follows` (`from_id`),
  KEY `FK_follows2` (`to_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `follows`
--

INSERT INTO `follows` (`follow_id`, `from_id`, `to_id`) VALUES
(6, 33, 28),
(7, 46, 28),
(8, 46, 38),
(9, 46, 36),
(10, 36, 46),
(11, 36, 44),
(12, 36, 33),
(17, 28, 46),
(18, 28, 34),
(19, 28, 31),
(20, 28, 32),
(21, 28, 47),
(22, 28, 29),
(23, 28, 36),
(24, 28, 33),
(25, 46, 29),
(26, 46, 33),
(27, 46, 47),
(28, 46, 32),
(29, 31, 46),
(30, 31, 28);

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
CREATE TABLE IF NOT EXISTS `likes` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `tweet_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`like_id`),
  KEY `FK_tweet_id_idx` (`tweet_id`),
  KEY `FK_user_id_idx` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`like_id`, `tweet_id`, `user_id`, `date_created`) VALUES
(8, 57, 28, '2021-12-11 19:22:39'),
(10, 56, 28, '2021-12-11 19:35:35'),
(11, 55, 28, '2021-12-11 19:45:18'),
(12, 56, 31, '2021-12-11 19:45:39'),
(13, 57, 31, '2021-12-11 19:46:18'),
(14, 56, 46, '2021-12-16 17:23:13'),
(15, 52, 46, '2021-12-16 17:23:20'),
(16, 31, 46, '2021-12-16 17:23:44'),
(17, 30, 46, '2021-12-16 17:23:48'),
(18, 29, 46, '2021-12-16 17:23:53'),
(19, 60, 46, '2021-12-16 17:24:21');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `message_text` varchar(255) NOT NULL,
  `date_sent` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_toid_idx` (`id`,`from_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `from_id`, `to_id`, `message_text`, `date_sent`) VALUES
(1, 28, 36, 'Hi Jim. What\'s it like being a space worm?', '2021-12-13 15:03:50'),
(7, 36, 28, 'I\'m not Spaceworm Jim. Stop calling me a worm. I am a HUMAN.', '2021-12-13 15:21:19'),
(10, 28, 28, 'Hello, me. How am you doing today?', '2021-12-14 12:07:44'),
(11, 28, 31, 'hi', '2021-12-14 20:23:27'),
(12, 28, 32, 'I fixed messaging. Now you can\'t randomly DM people and complain about aliens.', '2021-12-14 20:43:51');

-- --------------------------------------------------------

--
-- Table structure for table `tweets`
--

DROP TABLE IF EXISTS `tweets`;
CREATE TABLE IF NOT EXISTS `tweets` (
  `tweet_id` int(11) NOT NULL AUTO_INCREMENT,
  `tweet_text` varchar(280) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `original_tweet_id` int(11) NOT NULL DEFAULT '0',
  `reply_to_tweet_id` int(11) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tweet_id`),
  KEY `FK_tweets` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tweets`
--

INSERT INTO `tweets` (`tweet_id`, `tweet_text`, `user_id`, `original_tweet_id`, `reply_to_tweet_id`, `date_created`) VALUES
(17, 'time fixed?', 46, 0, 0, '2021-11-13 00:56:54'),
(18, 'Is the communicator working? \r\n', 36, 0, 0, '2021-11-13 00:58:57'),
(19, 'lofi = best', 46, 0, 0, '2021-11-14 17:28:55'),
(20, 'lofi tweet test 2', 46, 0, 0, '2021-11-14 17:33:44'),
(22, 'does it still work :?', 46, 0, 0, '2021-11-14 17:35:23'),
(27, 'Is the communicator working? \r\n', 46, 18, 0, '2021-11-14 19:29:41'),
(28, 'Is the communicator working? \r\n', 46, 27, 0, '2021-11-14 19:50:33'),
(29, 'Super Idolçš„ç¬‘å®¹ðŸŒ•\r\néƒ½æ²¡ä½ çš„ç”œ. ðŸŒ™\r\nå…«æœˆæ­£åˆçš„é˜³å…‰. ðŸ’«\r\néƒ½æ²¡ä½ è€€çœ¼.  â­ï¸\r\nçƒ­çˆ± 105 Â°Cçš„ä½ . ðŸŒŸ\r\n', 47, 0, 0, '2021-11-14 20:13:49'),
(30, 'æ»´æ»´æ¸…çº¯çš„è’¸é¦æ°´.   âœ¨\r\nä½ ä¸çŸ¥é“ä½ æœ‰å¤šå¯çˆ±.  âš¡ï¸\r\nè·Œå€’åŽä¼šå‚»ç¬‘ç€å†ç«™èµ·æ¥.  â„ï¸\r\nä½ ä»Žæ¥éƒ½ä¸è½»è¨€å¤±è´¥. â˜ƒï¸\r\nå¯¹æ¢¦æƒ³çš„æ‰§ç€ä¸€ç›´ä¸æ›¾æ›´æ”¹. ðŸŒˆ\r\n', 47, 0, 0, '2021-11-14 20:14:30'),
(31, 'å¾ˆå®‰å¿ƒ å½“ä½ å¯¹æˆ‘è¯´. ðŸŒ…\r\nä¸æ€•æœ‰æˆ‘åœ¨.  ðŸŽ‡\r\næ”¾ç€è®©æˆ‘æ¥. ðŸŒ†\r\nå‹‡æ•¢è¿½è‡ªå·±çš„æ¢¦æƒ³. ðŸŒŒ\r\né‚£åšå®šçš„æ¨¡æ ·. ðŸŒ„', 47, 0, 0, '2021-11-14 20:14:42'),
(32, 'Is the communicator working? \r\n', 28, 28, 0, '2021-11-14 22:53:29'),
(33, 'Is the communicator working? \r\n', 28, 32, 0, '2021-11-14 23:39:38'),
(37, 'no u', 28, 32, 33, '2021-11-15 00:23:13'),
(38, 'yo. yo dayo.', 28, 32, 37, '2021-11-15 00:28:49'),
(41, 'yo. yo dayo.', 28, 32, 33, '2021-11-15 00:56:16'),
(42, 'He\'s speaking str8 fax..', 28, 32, 33, '2021-11-15 00:57:25'),
(43, 'He\'s speaking str8 fax.', 28, 0, 31, '2021-11-15 00:57:37'),
(44, 'Woke.', 28, 0, 29, '2021-11-15 00:58:05'),
(45, 'Woke.', 28, 32, 33, '2021-11-15 01:06:12'),
(46, 'Woke.', 28, 32, 33, '2021-11-15 01:07:52'),
(47, 'Woke.', 28, 32, 33, '2021-11-15 01:33:42'),
(48, 'True.', 28, 0, 31, '2021-11-15 01:46:47'),
(49, 'AAAAAAAAAAAAAAAAAA', 28, 32, 33, '2021-11-16 19:09:13'),
(50, 'æˆ‘æ€Žæ ·æ‰èƒ½æˆä¸ºSUPER IDOLï¼Ÿ', 28, 0, 30, '2021-11-16 19:10:52'),
(51, 'nvm', 28, 0, 30, '2021-11-16 19:14:51'),
(52, 'asdf', 28, 0, 0, '2021-11-25 18:13:59'),
(53, '', 28, 0, 0, '2021-11-25 18:14:05'),
(54, 'testing if i fixed retweet originalTweetId', 28, 18, 27, '2021-11-25 18:34:33'),
(55, 'Is the communicator working? \r\n', 28, 18, 0, '2021-11-25 18:35:07'),
(56, 'Is the communicator working? \r\n', 28, 18, 0, '2021-11-25 18:35:13'),
(57, 'Is the communicator working? \r\n', 31, 18, 0, '2021-11-28 16:34:47'),
(58, 'Is the communicator working? \r\n', 31, 18, 0, '2021-12-11 19:46:22'),
(59, 'Is the communicator working? \r\n', 31, 18, 0, '2021-12-11 19:50:11'),
(60, 'asdf', 46, 0, 0, '2021-12-16 17:23:26'),
(64, 'retweet test', 46, 61, 0, '2021-12-16 18:22:26'),
(65, 'asdf', 28, 60, 0, '2021-12-16 18:46:18'),
(66, 'retweet test', 46, 61, 0, '2021-12-16 18:50:14'),
(67, '', 46, 53, 0, '2021-12-16 18:50:22'),
(68, 'asdf', 46, 52, 0, '2021-12-16 18:50:26'),
(69, 'double test', 46, 61, 66, '2021-12-16 18:55:43'),
(70, 'fresh tweet test', 28, 0, 0, '2021-12-16 18:59:50'),
(71, 'Fresh reply test', 28, 0, 70, '2021-12-16 19:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `screen_name` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `address` varchar(200) NOT NULL,
  `province` varchar(50) NOT NULL,
  `postal_code` varchar(7) NOT NULL,
  `contact_number` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `url` varchar(50) NOT NULL,
  `description` varchar(160) NOT NULL,
  `location` varchar(50) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `profile_pic` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `screen_name`, `password`, `address`, `province`, `postal_code`, `contact_number`, `email`, `url`, `description`, `location`, `date_created`, `profile_pic`) VALUES
(28, 'Nick', 'Taggart', 'nick', '$2y$10$mnE04r/ezGsl.RBU.jsrvu3xJVXo5XQ6JPs1XYCFx78IRmzrHDaVq', '123 Teacher Avenue', 'New Brunswick', 'T3A 5E7', '(123)456-7890', 'nicktaggart@nbcc.ca', 'nickhangout', 'Hi, I\'m nick. I teach at NBCC.', '', '2021-10-31 15:51:30', '281636667450pop_cat.png'),
(29, 'testfname\'', 'testlname\'', 'test\'', '$2y$10$VKEyzlL5f5eW0wNBOByz2O.dyLpVZ3gXMlFvNjj9GGNmY6lZBaUPy', 'Home\'s home', 'Prince Edward Island', 'E4E 4E4', '(999)999-9999', 'test*&\' ', 'here\'*>;', 'hi, i\'m a test.', '', '2021-10-31 15:54:32', '291635951459WIndows XP.png'),
(30, '<b>BOLD</b>', '<b>MC BOLDER</b>', 'the <b>BOLDER</b>', '$2y$10$qGCoJ./RCK.r/8I/7p2.qOmOy.twXfjiur.yEK/0dWmr1.XycsDKO', '<b>Bolder</b> avenue', 'Alberta', 'K7D 8E3', '(000)832-8345', 'e', 'bolderhangout', 'Hi. I like <b>BOLD</b>', '', '2021-11-03 15:08:17', ''),
(31, 'Abraham', 'Lincoln', 'abe_lincoln', '$2y$10$a2eTmvwTwIxf67G1/YgjOuyDOdr1yqwVcE1wiCJxK2R/eqv1hTgZS', '413 S. 8th Street Springfield', 'Alberta', 'A8E 1N4', '(217)492-4241', 'abelincoln@america.usa', 'abelincoln', 'America. *Bald eagle swoops by*', 'Contemplating by the fire.', '2021-11-05 20:48:07', ''),
(32, 'Donald', 'Trump', 'the_real_donald_trump', '$2y$10$zOQnweLsi.X2Sdb7SDSuVeAX1KTFB2MvgsTWgVs4oGyhgmJnU5n5q', '17 Donald dr.', 'Ontario', 'Y3E 8E7', '(134)431-8892', 'DonaldTrump@hotmail.com', 'therealdonald', 'I am the real donald trupm. we need to builf a wall.', 'a small ontario shop eating pikrel. Not bad.', '2021-11-05 20:54:18', ''),
(33, 'Julius', 'Caesar', 'Caesar', '$2y$10$JBG1m1aviXHkxF7F2w3klucdkD0eQ63ejDTWFUOBZ0RlqF5BLa.je', 'Caesar\'s Palace', 'Northwest Territories', 'R0M 3V4', '(112)094-2910', 'Caesar_Julius@hotmail.com', 'caesarspalace', 'Hi. I\'m a single senator looking for someone to liven up my life.', 'At my desk.', '2021-11-11 20:45:06', '331636763154Julius_Caesar.jpg'),
(34, 'fn', 'ln', 'fl2', '$2y$10$0ocbaO2R/bYo2kM625FU.ePGmQcTDJLtNtZMZVJ.yPC0ihs6lzlEK', '123 canton', 'Prince Edward Island', 'R4R 4R4', '(999)999-0000', 'fn@hotmail.com', 'fn_ln_hangout', 'hi. i\'m generic test character', 'home', '2021-11-12 22:45:56', ''),
(36, 'Jim', 'Kerk', 'Jim_Kirk', '$2y$10$Su6fNmz6VqjZiAacQTXumOxwZeGZ1ZW4z0JDunr7YQxzDfKPVEn5S', 'Captain\'s quarters, Enterprise NCC-1701', 'Yukon', 'E7T 9S3', '(831)391-0318', 'JimKirk@spacemail.ufp', 'r/captainsquarters', 'hi. Single captain here. If your like off-hand sexism and dead redshirts, I\'m your guy. ', 'The bridge', '2021-11-12 22:59:56', '361636765204MWR1.gif'),
(38, 'b', 'b', 'b', '$2y$10$g/T5aJmXIGl5RpRWvcUMxewW736bJ7.lwGA3GbYbmUqbfpVxemp06', 'b', 'Nova Scotia', 'E4E 3E3', '(999)999-9999', 'b', 'e', 'e', 'e', '2021-11-12 23:02:06', ''),
(40, 'e', 'e', 'e', '$2y$10$/LB2oHWDxpNDiVQ71TNbQ.0dw6k4j1D1PiewFBYjwhumBX7Obk5ZO', 'e', 'Saskatchewan', 'E4E 4E4', '(999)999-9999', 'e', 'e', 'e', 'e', '2021-11-12 23:06:35', ''),
(44, 'e', 'e', 'e2', '$2y$10$H57iBfwVMcun4twVLGR8E.RkCWICurD7vsKSHqpjDpY925b9F/EB2', 'e', 'Prince Edward Island', 'E4E 4E4', '(999)999-9999', 'e', 'e', 'e', 'e', '2021-11-12 23:21:40', ''),
(45, 'z', 'z', 'z', '$2y$10$qODj15wLBH.60yy0gMe6r..DNQOR8MUEzMZxeijvHpWAGlIo3QYS6', 'z', 'Northwest Territories', 'Z3Z 3Z3', '(999)999-9999', 'z', 'z', 'z', 'z', '2021-11-12 23:25:36', ''),
(46, 'lofi', 'girl', 'lofi_girl', '$2y$10$BnOCWXe.vwuJ2p5dl7hre.DyRaVh/Yz8sPdD9wabs2mu88bW9oRLG', '77 Chill st.', 'Quebec', 'L0F 1G1', '(607)283-9314', 'lofi_girl@gmail.com', 'lofihangout', 'Hi. I stream 24 hour lo-fi music. ', 'At my desk', '2021-11-13 04:33:08', '461636763709download.jpg'),
(47, 'Super Idol', ' çš„ç¬‘å®¹éƒ½æ²¡ä½ çš„ç”œ ', 'Super_idol', '$2y$10$BYPHgAmj3wfNfnxgM0ki5.2zJNDE3qKk/dGYLoAuiwmhFGBVStRZS', 'Ning Qiao Lu 888hao Ke Ji Da Lou 11lou Cai Wu Bu', 'Northwest Territories', 'S7P 3R6', '(306)380-8032', 'Zmcmtianyiming@wechat.com', 'super_idol_zmcmtianyiming_', 'Super Idolçš„ç¬‘å®¹ðŸŒ• éƒ½æ²¡ä½ çš„ç”œ. ðŸŒ™ å…«æœˆæ­£åˆçš„é˜³å…‰. ', 'å±žäºŽæˆ‘çš„æ—¶ä»£.', '2021-11-15 00:04:57', '471636920759super_idol3.png');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `follows`
--
ALTER TABLE `follows`
  ADD CONSTRAINT `FK_follows` FOREIGN KEY (`from_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `FK_follows2` FOREIGN KEY (`to_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `FK_tweet_id` FOREIGN KEY (`tweet_id`) REFERENCES `tweets` (`tweet_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `tweets`
--
ALTER TABLE `tweets`
  ADD CONSTRAINT `FK_tweets` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
