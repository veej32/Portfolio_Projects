<?php 
//insert a tweet into the database
include("connect.php");
include("includes/Tweet.php");
if (isset($_POST["myTweet"])){
    //retieve user's id and the tweet
    session_start();
    $userId = $_SESSION["SESS_MEMBER_ID"];
    $tweetText = $_POST["myTweet"];
    $tweet = new Tweet(0, 0, $tweetText, 0, $userId, 0);
    Tweet::postTweet($con, $tweet);
}
?>