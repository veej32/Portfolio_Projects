<script type="text/javascript" src="../Includes/jquery.simplemodal.js"></script>
<?php include("connect.php"); ?>
<?php include("Includes/User.php");?>
<?php 
//this file will handle the file uploading and return the user back to the edit_photo page.
if (isset($_POST["upload_picture"])){
    $MAX_FILE_SIZE = 5 * 1025 * 1024; //5MB
    $failurePage = "edit_photos.php";
    $successPage = "index.php";
    User::editPhoto($con, $MAX_FILE_SIZE, $failurePage, $successPage);
}//end if

?>