<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bitter: Search Results">
    <meta name="author" content="Alex V.J. Hunter - alex2infinity@gmail.com">
    <link rel="icon" href="favicon.ico">

    <title>Contact Us - Bitter</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">
	<!-- Bootstrap core JavaScript-->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
	
    <script src="includes/bootstrap.min.js"></script>
    
  </head>

  <body>
      <?php
        session_start();
        //redirect user to Login page if not logged in
        if (!isset($_SESSION["SESS_MEMBER_ID"])) {
            header("location:Login.php");
        }       
      ?>
    <?php 
        Include("Includes/header.php"); 
        Include_once("Includes/User.php");
        Include_once("Includes/Tweet.php");
    ?>
    <?php 
        $search = mysqli_real_escape_string($con, strtoupper($_GET['search']));
        $id = (int) $_SESSION["SESS_MEMBER_ID"];
        $user = User::getUserByUserId($con, $id);
        $arr = $user->search($con, $search);
    ?>   
      
    <div class="container">
        <div class="row">
          <div class="col-sm-6 mx-auto img-rounded">
              <div class="bold" style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;' >
                  <h2 align="center">Users Found:</h2>
                  <hr>
                    <?php     
                    foreach ($arr['users'] as $user){
                        echo "<form method='post' action='follow_proc.php?user_id=" . $user->userId . "'>" ;
                        echo "<a href='userpage.php?user_id=" . $user->userId . "'>";
                        echo substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 50) . "</a>";
                        if ($user->checkIfFollowedBy($con, $id)) echo " | Following"; 
                        else if ($user->userId != $id) {
                            echo " <input type='submit' name='follow_button' id='follow_button' value='follow' class='followbutton btn btn-primary'/>";
                        }
                        if ($user->checkIfFollowing($con, $id)) echo " | Follows You";
                        echo "</form><hr>";
                    } 
                  ?>
              </div>
              <div style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;'>
                  <h2 align="center">Tweets Found:</h2>
                  <hr>
                  <?php 
                    foreach ($arr['tweets'] as $tweet){
                        echo "<div style='background-color:#dddddd; padding:0.25em; margin:0.25em;'> ";
                        $tweet->print($con);
                        echo "</div><hr>"; 
                    } 
                  ?>
              </div>
          </div>
        </div>
    </div>
      
  </body>
</html>