<?php	
    	        
    function getProvCode($province){
        switch($province) {
        case "British Columbia":            return "BC";
        case "Alberta":                     return "AB";
        case "Saskatchewan":                return "SK";
        case "Manitoba":                    return "MB";
        case "Ontario":                     return "ON"; 
        case "Quebec":                      return "QC"; 
        case "New Brunswick":               return "NB"; 
        case "Prince Edward Island":        return "PE"; 
        case "Nova Scotia":                 return "NS";
        case "Newfoundland and Labrador":   return "NL"; 
        case "Northwest Territories":       return "NT"; 
        case "Nunavut":                     return "NU"; 
        case "Yukon":                       return "YT"; 
        default: return null;
        }
    }
    include('Includes/ValidatePostalCodeWS.php');
    
    $msg = "";
    if (isset($_GET["postalCode"]) && isset($_GET["province"])) {
        
        
        
        //$json_out = '{"msg":"SUCCESS"}';
        $postalCode = $_GET["postalCode"];
        $province = $_GET["province"];
        $provCode = getProvCode($province);
  
              
        
        if ($provCode != null) {
            $msg = " ProvCode: " . $provCode . " postalCode: " . $postalCode . "<BR>";
            //$msg = "valid";
            $msg .= validatePostalCode_Fedex($postalCode, $provCode);
        }
        //else $msg = " Province & postal required.";
        echo '{"msg":"' . $msg . '"}';
    } 
?>

