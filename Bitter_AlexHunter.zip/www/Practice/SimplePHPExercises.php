<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // Question #1
        echo "<b>Question #1</b><BR><hr>";
        $var1=10;
        $var2=10;
        echo $var1==$var2 ? "EQUAL<BR>" : "not equal<BR>";
        echo "<BR>";
        
        // Question #2
        echo "<hr><b>Question #2</b><BR><hr>";
        echo "<table border='1px solid black'>";
        for ($i=1; $i<=7; $i++){
            echo "<tr>";
            for ($j=1; $j<=7; $j++){
                echo "<th>" . ($i * $j) . "</th>";
            }
            echo "</tr>";
        }
        echo "</table><BR>";
        
        // Question #3
        echo "<hr><b>Question #3</b><BR><hr>";
        echo "<table border='1px solid black'>"
        . "<tr><th style='color:blue'>Apples cost</th><th>$4</th></tr>"
        . "<tr><th style='color:blue'>Oranges cost</th><th>$1.99</th></tr>"
        . "<tr><th style='color:blue'>Bananas cost</th><th>$0.89</th></tr>"        
        . "</table>";
        ?>
    </body>
</html>
