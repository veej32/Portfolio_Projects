<?php include("connect.php"); ?>
<?php include("Includes/User.php"); ?>
<?php 
if (isset($_POST["firstname"])){ //make sure that the user got here properly 
    //insert the user's data into the users table of the DB
    //if everything is successful, redirect them to the login page.
    //if there is an error, redirect back to the signup page with a friendly message
    
    //get form information 
    $firstName = $_POST["firstname"];
    $lastName = $_POST["lastname"];
    $email = $_POST["email"];
    $username = $_POST["username"]; 
    $password = $_POST["password"];
    $confirm = $_POST["confirm"]; //TODO actually confirm previous password
    $phone = $_POST["phone"]; 
    $address = $_POST["address"];
    $province = $_POST["province"]; 
    $postal = $_POST["postalCode"];
    $url = $_POST["url"];
    $desc = $_POST["desc"];
    $location = $_POST["location"];
    
 
    //create a new user object with the information
    $newUser = new User(0, $username, $password, $firstName, $lastName, $address, $province, $postal, $phone, $email, date("Y-m-d H:i:s"), "", $location, $desc, $url);
    //try to create/insert in the database
    User::createUser($con, $newUser);    
}
?>