<?php
    session_start();
    //redirect user to Login page if not logged in
    if (!isset($_SESSION["SESS_MEMBER_ID"])) {
        header("location:Login.php");
    }
?>
<script src="https://code.jquery.com/jquery-3.3.1.js" ></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<?php include_once("connect.php"); ?>
<?php include_once("Includes/User.php"); ?>
<?php include_once("Includes/Tweet.php"); ?>
<?php include_once("Includes/Message.php"); ?>

<?php include("Includes/GetMessage.php");?>
<?php

    //get user's id to use throughout page
    $id = $_SESSION["SESS_MEMBER_ID"];
    
?>



 <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <script src="includes/bootstrap.min.js"></script>


<BR><BR>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bitter: Direct Message someone and make their day worse.">
    <meta name="author" content="Alex Hunter, alex2infinity@gmail.com">
    <link rel="icon" href="favicon.ico">

    <title>Bitter - Social Media for Trolls, Narcissists, Bullies and Presidents.</title>

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">

  </head>

  <body>
    <?php include("Includes/header.php"); ?>
    <?php include 'includes/Modals.php'; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                    <div class="mainprofile img-rounded">
                    <div class="bold">
                        <?php //get & display profile information for the user
                            $user = User::getUserByUserId($con, $id);
                            if ($user->profImage!= "") $profile_pic = $user->profImage;
                            else $profile_pic = "default.jfif";
                            $name = $user->firstName . " " . $user->lastName;

                            echo '<img class="bannericons" src="images/profilepics/'.$profile_pic.'">';
                            echo '<a href="userpage.php?user_id='.$id.'">'. $name. '</a><BR></div>';
                            ?>

                    <table>
                        <tr><td>tweets</td><td>following</td><td>followers</td></tr>
                        <tr>
                            <td><?php echo $user->getNumTweets($con)?></td>
                            <td><?php echo $user->getNumFollowing($con)?></td>
                            <td> <?php echo $user->getNumFollowers($con)?>       </td>
                        </tr>
                    </table>
                    <img class="icon" src="images/location_icon.jpg">
                            <?php echo $user->province;?>
                        <div class="bold">Member Since:</div>
                        <div><?php echo date_format(date_create($user->dateAdded), "F jS, Y");?></div>
                    </div><BR><BR>
                    <div class="trending img-rounded">
                        <div class="bold">Trending</div>
                    </div>

            </div>
            <div class="col-md-6">
                <div style='background-color:#dddddd; border-radius:0.3em; padding:1em; margin-bottom:1em;'>
                  <h2 align="center">Your Messages:</h2>
                  <hr>
                  <?php 
                    $messages = $user->GetAllMessages($con);
                    foreach ($messages as $message){
                        echo "<div style='background-color:#dddddd; padding:0.25em; margin:0.25em;'> ";
                        echo $message->timeSinceSent() . "<BR>";
                        if ($message->fromId == $id){ //executes when message is from the current user
                            $toUser = User::getUserByUserId($con, $message->toId);
                            $linkText = $toUser->firstName . " " . $toUser->lastName . " @" . $toUser->userName;
                            echo 'Sent To: ' . '<a href = "userpage.php?user_id='.$toUser->userId.'">' . $linkText . '</a>';
                            echo '<div style="margin-left:1em; margin-top:0.25em;">' . $message->messageText .  '</div>';
                           
                        }
                        else {
                            $fromUser = User::getUserByUserId($con, $message->fromId);
                            $linkText = $fromUser->firstName . " " . $fromUser->lastName . " @" . $fromUser->userName;
                            echo 'Recieved From: ' . '<a href = "userpage.php?user_id='.$fromUser->userId.'">' . $linkText . '</a><br>';     
                            echo '<div style="margin-left:1em; margin-top:0.25em;">' . $message->messageText .  '</div>';
                        }
                        
                        echo "</div><hr>"; 
                    } 
                  ?>
                </div>
            </div>
            
              
            <div class="col-md-3">
                    <div class="whoToTroll img-rounded">
                    <div class="bold">Who to Troll?<BR></div>
                    <!-- display people you may know here-->
                    <?php  
                        echo
                        User::whoToTroll($con);                             
                    ?>
                    </div><BR>
                    <!--don't need this div for now 
                    <div class="trending img-rounded">
                    © 2021 Bitter
                    </div>-->
            </div>
        </div> <!-- end row -->
    </div><!-- /.container -->

    
  </body>
</html>

