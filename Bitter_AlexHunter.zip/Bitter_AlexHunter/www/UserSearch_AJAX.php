<?php
    include_once("connect.php");
    include_once("Includes/Tweet.php");
    include_once("Includes/User.php");
    //this is for sprint 6
    //we'll finish writing this code in class
    session_start();
    $screenName = $_GET["to"]; //grab whatever the user typed
    $userId = $_SESSION["SESS_MEMBER_ID"];
    
    GetUsers($con, $screenName, (int) $userId);
    

function GetUsers(mysqli $con, String $search, int $userId) {
    //run a DB query to retriev the users matching given screen name
    //Join with the follows tbale to get only that they follow
    //$sql = "select * from users where screen_name like '%$screenName%'
    // inner join follows f on f.from_id = u.user_id;
    //put this in funciton of your users class 
    //loop through the results and build an array
    //json_encode the resulting array and return it
    
    //it will do this for each new letter typed

    $current_user = User::getUserByUserId($con, $userId);         
    
    $search = mysqli_real_escape_string($con, $search);
    
    //get users matching criteria
    $sql_users = "SELECT u.* FROM `users` u"
        . " INNER JOIN `follows` f on f.to_id = u.user_id"
        . " WHERE (UPPER(screen_name) LIKE '%$search%')"
        . " AND (f.from_id = " . $userId . ");";
    
    $userList = array();
    if ($result = mysqli_query($con, $sql_users)){ 
        
        while ($row = mysqli_fetch_array($result)){
            $userInfo = array('id'=>$row["user_id"], 'name'=>($row["first_name"] . " " . $row["last_name"]), 'username'=>$row["screen_name"]);
            array_push($userList, $userInfo);
        }
        $json_data = json_encode($userList);
        
    }
    echo $json_data;    
}

?>