<?php include("connect.php"); //you may need to change this - nope it works for me?>
<?php include("Includes/User.php"); ?>
<?php
if (isset($_GET["username"])) {
    //put logic here to query the Users table of the DB and check if the username already exists
    $username = $_GET["username"];
    $json_out = '{"valid":false}';
    $myUser = User::getUserByScreenName($con, $username, false);
    if ($myUser == null) {
        $json_out = '{"valid":true}';
    }
    else {
        $json_out = '{"valid":false}';
    }
    
    echo $json_out;
}
?>