<?php include("includes/User.php");?>
<?php include("includes/Tweet.php");?>
<?php
session_start();
//redirect user to Login page if not logged in
    if (!isset($_SESSION["SESS_MEMBER_ID"])) {
        header("location:Login.php");
    } 
    //redirect user to home page if not accessed properly
    else if (!isset($_GET['user_id'])) {
        header("location:index.php");
    }
?>
<?php include("connect.php"); ?>
<?php
//this is the main page for our Bitter website, 
//it will display all tweets from those we are trolling
//as well as recommend people we should be trolling.
//you can also post a tweet from here
    
?>
<?php
//displays all the details for a particular Bitter user
?>
<BR><BR>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Bitter - Social Media for Trolls, Narcissists, Bullies and Presidents</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">
	<!-- Bootstrap core JavaScript-->
    <script src="https://code.jquery.com/jquery-1.10.2.js" ></script>
	
	
  </head>

  <body>
    <?php Include("Includes/header.php"); ?>
    <div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="mainprofile img-rounded">
                                    <div class="bold">
                                     <?php //dsiplay user's profile information
                                        $id = $_GET['user_id'];
                                        $user = User::getUserByUserId($con, $id);
                                            if ($user->profImage!= ""){
                                                $profile_pic = $user->profImage;
                                            }
                                            else {
                                                $profile_pic = "default.jfif";
                                            }
                                            $name = $user->firstName . " " . $user->lastName;
                                        
                                        echo '<img class="bannericons" src="images/profilepics/' . $profile_pic . '"> ';
                                        echo  ' ' . $name;
                                        ?>
                                    <BR></div>
                                    <table>
                                        <tr><td>tweets</td><td>following</td><td>followers</td></tr>
                                        <tr>
                                            <td><?php echo $user->getNumTweets($con)?></td>
                                            <td><?php echo $user->getNumFollowing($con)?></td>
                                            <td> <?php echo $user->getNumFollowers($con)?>       </td>
                                        </tr>
                                    </table>
                                    <img class="icon" src="images/location_icon.jpg">
                                        <?php echo $user->province;?>
                                    <div class="bold">Member Since:</div>
                                    <div><?php echo date_format(date_create($user->dateAdded), "F jS, Y");?></div>
                                    </div><BR><BR>
				
				<div class="trending img-rounded" >
                                <?php //display information for who the user can follow
                                    $user->followersYouKnow($con);                                  
                                ?>			    
				</div>
				
			</div>
			<div class="col-md-6">
				<div class="img-rounded">
					
				</div>
				<div class="img-rounded">
                                    <?php       
                                        Tweet::displayTweets($con, $id, false);
                                     ?>
				</div>
			</div>
			<div class="col-md-3">
				<div class="whoToTroll img-rounded">
				<div class="bold">Who to Troll?<BR></div>
				<?php //display information for who the user can follow
                                    User::WhoToTroll($con);
                                ?>			
				
				</div><BR>
				
			</div>
		</div> <!-- end row -->
    </div><!-- /.container -->

	

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="includes/bootstrap.min.js"></script>
    
  </body>
</html>
