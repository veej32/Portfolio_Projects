<?php include("connect.php"); ?>
<?php include("Includes/User.php")?>
<?php 
//verify the user's login credentials. if they are valid redirect them to index.php/
//if they are invalid send them back to login.php
if (isset($_POST['username'])){//Only executes if user got to page via POST with username set
    //Test to see if there is a user in the bitter database with the username and password sent via POST
    $username = $_POST['username'];  
    $password = $_POST['password'];
    
    User::login($con, $username, $password);
}

?>