<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of Like
 *
 * @author alex2
 */
class Like {
    //put your code here
    
    private $like_id;
    private $tweet_id;
    private $user_id;
    private $date_created;
    
    public function __construct(int $like_id, int $tweet_id, int $user_id, string $date_created){
        $this->like_id = $like_id;
        $this->tweet_id = $tweet_id;
        $this->user_id = $user_id;
        $this->date_created = $date_created;      
    }
    
    public function print($con){
        echo "<div style='background-color:#dddddd; padding:0.25em; margin:0.25em;'> ";
        $user = User::getUserByUserId($con, $this->user_id);
        if ($user->profImage!= "") $profile_pic = $user->profImage;
        else $profile_pic = "default.jfif";
        echo '<img class="bannericons" src="images/profilepics/'.$profile_pic.'"> ';
        $linkText = substr($user->firstName . " " . $user->lastName . " @" . $user->userName, 0, 25);
        echo '<a href = "userpage.php?user_id='.$this->user_id.'">'.$linkText.'</a>'.' ';
        echo ' Liked your tweet ';
        date_default_timezone_set("America/Halifax");
        echo Tweet::timeFromPost($this->date_created);          
        $tweet = Tweet::GetTweet($con, $this->tweet_id);
        echo "<div style='padding-left:1em'>" . $tweet->tweetText . "</div>";
        echo "</div><hr>"; 
    }
    
    public function __destruct() {
        //nothing for now
    }
    
    public function __get($n){
        return $this->$n;
    }
    public function __set($property, $value){
        $this->$property = $value;
    }
}
