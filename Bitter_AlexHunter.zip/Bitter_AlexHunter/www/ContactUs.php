<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Bitter: Contact us">
    <meta name="author" content="Alex V.J. Hunter - alex2infinity@gmail.com">
    <link rel="icon" href="favicon.ico">

    <title>Contact Us - Bitter</title>

    <!-- Bootstrap core CSS -->
    <link href="includes/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="includes/starter-template.css" rel="stylesheet">
	<!-- Bootstrap core JavaScript-->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
	
    <script src="includes/bootstrap.min.js"></script>
    
  </head>

  <body>
      <?php
        session_start();
        //redirect user to Login page if not logged in
        if (!isset($_SESSION["SESS_MEMBER_ID"])) {
            header("location:Login.php");
        }
      ?>
    <?php Include("Includes/header.php"); ?>
      <!-- TODO - phone numbers, fax numbers, address, (optional) map, and clickable e-mail link to alex2infinity@gmail.com. -->
      <div class="container">
		<div class="row">
			<div class="main-center  mainprofile">
				<h1>Contact Bitter</h1>
                                <hr>
                                <table>
                                    <tr>
                                        <td>Phone:</td>
                                        <td>1 507-7255</td>
                                    </tr>
                                    <tr>
                                        <td>Fax:</td>
                                        <td>1 507-6382</td>
                                    </tr>
                                    <tr>
                                        <td>Phone:</td>
                                        <td>1 507-7255</td>
                                    </tr>
                                    <tr>
                                        <td>Address:</td>
                                        <td>237 Wilnot ave.<BR>Toronto, Ontario</td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td><a href="mailto:alex2infinity@gmail.com">Contact Bitter's Developer</a></a>
                                        </td>
                                      
                                    </tr>
                                    
                                </table>
			</div>
                </div>
      </div>
      
  </body>
</html>
