/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package DataLayer;

import BusinessLayer.Question;
import BusinessLayer.Quiz;
import BusinessLayer.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.Singleton;

/**
 *
 * @author alex2
 */
@Singleton
public class BuzzletDL {
    @EJB
    ConnectionFactory cf;
    private Connection conn;

    //Question methods    
    public boolean InsertQuestion(String question, String answer, int quiz_id){
        String sql = "INSERT INTO `question` " +
        "(`question`," +
        "`answer`," +
        "`quiz_id`) " +
        "VALUES (?,?,?);";
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, question);
            ps.setString(2, answer);
            ps.setInt(3, quiz_id);
            if (ps.executeUpdate() == 1) return true;
            else {
                System.out.println("ERROR: BuzzletDB.InsertQuestion didn't update a record!");
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    public Question FetchQuestionByQuestionId(int question_id){
        Question question = null;
        String sql = "SELECT `question`,"
                + "`answer`,"
                + "`quiz_id`,"
                + "`date_created`"
                + "FROM `question`"
                + "WHERE question_id = ?";
         PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setInt(1, question_id);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                 question = new Question(question_id, rs.getString("question"), rs.getString("answer"), rs.getInt("quiz_id"), rs.getDate("date_created"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return question;
    }  
    public ArrayList<Question> FetchQuestionsByQuizId(int quiz_id){
        ArrayList<Question> questions = new ArrayList<>();
         String sql = "SELECT "
                + "`question_id`,"
                + "`question`,"
                + "`answer`,"
                + "`date_created`"
                + "FROM `question`"
                + "WHERE quiz_id = ?";
         PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setInt(1, quiz_id);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                do {
                    Question question = new Question(rs.getInt("question_id"), rs.getString("question"), rs.getString("answer"), quiz_id, rs.getDate("date_created"));
                    questions.add(question);
                } while (rs.next());
                 
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return questions;
    }   
    public ArrayList<Question> FetchAllQuestions(){
        ArrayList<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM `question`;";
        PreparedStatement ps;
        try {
            Statement s = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = s.executeQuery(sql);
            if (rs.first()){
                do {
                    Question question = new Question(rs.getInt("question_id"), rs.getString("question"), rs.getString("answer"), rs.getInt("quiz_id"), rs.getDate("date_created"));
                    questions.add(question);
                } while (rs.next());
                 
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return questions;
    }
    //end of Question methods
    
    //Quiz methods
    public boolean InsertQuiz(String title, int user_id){
         String sql = "INSERT INTO `quiz` " +
            "(`title`, " +
            "`user_id`) " +
            "VALUES " +
            "(?, ?);";
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setInt(2, user_id); 
            if (ps.executeUpdate() == 1) return true;  
            else {
                System.out.println("ERROR: BuzzletDB.InsertQuiz didn't update a record!");
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }   
    public Quiz FetchQuizByQuizId (int quiz_id){
        Quiz quiz = null;
        String sql = "SELECT title, date_created, user_id "
                + "FROM quiz WHERE quiz_id = ?";  
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setInt(1, quiz_id);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                 quiz = new Quiz(quiz_id, rs.getString("title"), rs.getDate("date_created"), rs.getInt("user_id"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return quiz;
    }   
    public ArrayList<Quiz> FetchQuizzesByTitle(String title){
        ArrayList<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT quiz_id, date_created, user_id "
                + "FROM quiz WHERE title = ?";  
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setString(1, title);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                 do {
                     Quiz quiz = new Quiz(rs.getInt("quiz_id"), title, rs.getDate("date_created"), rs.getInt("user_id"));
                     quizzes.add(quiz);
                 }   while(rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return quizzes;
    }   
    public ArrayList<Quiz> FetchQuizzesByUserId(int user_id){
        ArrayList<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT quiz_id, title, date_created "
                + "FROM quiz WHERE user_id = ?";  
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setInt(1, user_id);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                 do {
                     Quiz quiz = new Quiz(rs.getInt("quiz_id"), rs.getString("title"), rs.getDate("date_created"), user_id);
                     quizzes.add(quiz);
                 }   while(rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return quizzes;
    }       
    public ArrayList<Quiz> FetchAllQuizzes(){
        ArrayList<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT * FROM quiz";
        PreparedStatement ps;
        try {
            Statement s = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = s.executeQuery(sql);
            if (rs.first()){
                do {
                    Quiz quiz = new Quiz(rs.getInt("quiz_id"), rs.getString("title"), rs.getDate("date_created"), rs.getInt("user_id"));
                    quizzes.add(quiz);
                } while (rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return quizzes;
    }
    //End of Quiz methods
    
    //User methods
    public boolean InsertUser(String user_name, String password){
         String sql = "INSERT INTO `user` " +
            "(`user_name`, " +
            "`password`) " +
            "VALUES " +
            "(?,?);";
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, user_name);
            ps.setString(2, password); 
            if (ps.executeUpdate() == 1) return true;  
            else {
                System.out.println("ERROR: BuzzletDB.InsertUser didn't update a record!");
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    public User FetchUserByUserId(int user_id){
        User user = null;
        String sql = "SELECT user_name, password, date_created "
                + "FROM user WHERE user_id = ?";  
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setInt(1, user_id);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                 user = new User(user_id, rs.getString("user_name"), rs.getString("password"), rs.getDate("date_created"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user;
    }
    public User FetchUserByUserName(String user_name){
        String sql = "SELECT user_id, password, date_created "
                + "FROM user WHERE user_name = ?";  
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE); 
            ps.setString(1, user_name);
            
            ResultSet rs = ps.executeQuery();
            if (rs.first()){
                 return new User(rs.getInt("user_id"), user_name, rs.getString("password"), rs.getDate("date_created"));                
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex){
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public ArrayList<User> FetchAllUsers(){
        ArrayList<User> users = new ArrayList<>();
        String sql = "SELECT * FROM user";
        PreparedStatement ps;
        try {
            Statement s = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet rs = s.executeQuery(sql);
            if (rs.first()){
                do {
                    User user = new User(rs.getInt("user_id"), rs.getString("user_name"), rs.getString("password"), rs.getDate("date_created"));
                    users.add(user);
                } while (rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return users;
    }
    //End of User methods
       
    @PostConstruct 
    private void initializeConnection() { conn = cf.getConnection();   }
    @PreDestroy
    private void Disconnect(Connection conn){ //executes right before destruction of object
        try {//close the connection
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(BuzzletDL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
