/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package BackingBeans;

import BusinessLayer.BuzzletBL;
import BusinessLayer.Quiz;
import java.io.Serializable;
import java.util.ArrayList;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

/**
 *
 * @author alex2
 */
@Named(value = "quizBackingBean")
@ViewScoped
public class QuizBackingBean implements Serializable{

    /**
     * Creates a new instance of QuizAddController
     */
    public QuizBackingBean() {
    }
 
    @Inject 
    private BuzzletBL bl;
    
    @Inject 
    private QuizTakingController quizTakingController;
    
    private String quizName;

    public String getQuizName()              {return quizName; }
    public void setQuizName(String quizName) {this.quizName = quizName; }
    
    
    
    public String AddQuiz(){
        String message;
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);

        Integer user_id = (Integer) session.getAttribute("user_id");

        boolean success = bl.AddQuiz(quizName, user_id);
        if (success) message = "Quiz Successfully Added"; 
        else message = "Error Adding Quiz!";
            
        //give user appropriate message
        return "index.xhtml?faces-redirect=true&msg=" + message;
    }
    
    public ArrayList<Quiz> GetQuizzesMade(){
        ArrayList<Quiz> quizzes = new ArrayList<>();
        
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        Integer user_id = (Integer) session.getAttribute("user_id");
        //String user_name = (String) session.getAttribute("user_name");
        
        quizzes = bl.GetQuizzesByUserId(user_id);
         
        return quizzes;
    }
    public ArrayList<Quiz>GetAllQuizzes(){
         ArrayList<Quiz> quizzes = new ArrayList<>();
         quizzes = bl.GetAllQuizzes();
         
         return quizzes;
         
    }
    
    public String GetQuizCreator(int user_id){
        return bl.GetUserByUserId(user_id).getUserName();
    }
    
    public String EditQuiz(int quiz_id){
        
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);

        Integer user_id = (Integer) session.getAttribute("user_id");
        
        //get the quiz from the database and make sure it was made by the user
        Quiz quiz = bl.GetQuizByQuizId(quiz_id);
        
        if (quiz.getUser_id() == user_id){
            
            //quiz was made by user. Send to quiz editor page
            return "QuizEditor.jsp?faces-redirect=true&quiz_id=" + quiz_id;
            
            
        }
        else {
            String message = "You can only edit quizzes you made!";
            return "index.xhtml?faces-redirect=true&msg=" + message;
        }  
    }
    
    public String TakeQuiz(int quiz_id){
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);

        session.setAttribute("quiz_id", quiz_id);
        
        
        quizTakingController.InitializeQuiz();
        
        //get the quiz from the database and make sure it was made by the user
        if (bl.GetQuizByQuizId(quiz_id) != null) {
            return "TakeQuiz.xhtml?faces-redirect=true";
        }
        else {
            String message = "Sorry, That quiz doesn't exist!";
            return "index.xhtml?faces-redirect=true&msg=" + message;
        }     
    }
    
}
