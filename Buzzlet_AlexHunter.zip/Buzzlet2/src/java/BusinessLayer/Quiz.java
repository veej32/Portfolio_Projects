/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package BusinessLayer;

import java.util.Date;
import javax.ejb.Stateless;

/**
 *
 * @author alex2
 */
@Stateless
public class Quiz {
    private int quiz_id;
    private String title;
    private java.util.Date date_created;
    private int user_id;

    public Quiz(int quiz_id, String title, Date date_created, int user_id) {
        this.quiz_id = quiz_id;
        this.title = title;
        this.date_created = date_created;
        this.user_id = user_id;
    }
    public Quiz() {
        //default constructor
    }
    public int      getQuiz_id()                {return quiz_id;}
    public void     setQuiz_id(int quiz_id)     {this.quiz_id = quiz_id;}
    public String   getTitle()                  {return title;}
    public void     setTitle(String title)      {this.title = title;}
    public Date     getDate_created()                  {return date_created;}
    public void     setDate_created(Date date_created) {this.date_created = date_created;}
    public int      getUser_id()                {return user_id;}
    public void     setUser_id(int user_id)     {this.user_id = user_id;}

    
}
