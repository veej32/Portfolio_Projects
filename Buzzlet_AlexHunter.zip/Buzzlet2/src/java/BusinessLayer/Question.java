/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package BusinessLayer;

import java.util.Date;
import javax.ejb.Stateless;

/**
 *
 * @author alex2
 */
@Stateless
public class Question {
    private int question_id;
    private String question;
    private String answer;
    private int quiz_id;
    private java.util.Date date_created;
    
    public Question(int question_id, String question, String answer, int quiz_id, Date date_created) {
        this.question_id = question_id;
        this.question = question;
        this.answer = answer;
        this.quiz_id = quiz_id;
        this.date_created = date_created;
    }
    public Question() {
        //default constructor
    }
    public int    getQuestion_id()                  {return question_id;}
    public void   setQuestion_id(int question_id)   {this.question_id = question_id;}
    public String getQuestion()                     {return question;}
    public void   setQuestion(String question)      {this.question = question;}    
    public String getAnswer()                       {return answer;}
    public void   setAnswer(String answer)          {this.answer = answer;} 
    public int    getQuiz_id()                      {return quiz_id;}
    public void   setQuiz_id(int quiz_id)           {this.quiz_id = quiz_id;}   
    public Date getDate_created()                   {return date_created;}
    public void setDate_created(Date date_created)  {this.date_created = date_created;}
}
