/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package BusinessLayer;

import java.util.Date;
import javax.ejb.Stateless;

/**
 *
 * @author alex2
 */
@Stateless
public class User {
    private int userId;
    private String userName;
    private String password;
    private java.util.Date dateCreated;
    
    public User(int userId, String userName, String password, Date dateCreated) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.dateCreated = dateCreated;
    }  
 
    public User() {
        //default constructor
    }
    
    public int getUserId()              {return userId;  }
    public void setUserId(int userId)   {this.userId = userId;}
    public String getUserName()             {return userName;}
    public void setUserName(String userName){this.userName = userName;}    
    public String getPassword()             {return password;}
    public void setPassword(String password){this.password = password;}   
    public Date getDateCreated()                {return dateCreated;}
    public void setDateCreated(Date dateCreated){this.dateCreated = dateCreated;}

}
