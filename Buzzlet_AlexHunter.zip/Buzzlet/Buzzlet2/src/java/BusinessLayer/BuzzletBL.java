/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB31/SingletonEjbClass.java to edit this template
 */
package BusinessLayer;

import DataLayer.BuzzletDL;
import java.util.ArrayList;
import javax.ejb.EJB;
import javax.ejb.Singleton;

/**
 *
 * @author alex2
 */
@Singleton
public class BuzzletBL {
    @EJB
    BuzzletDL dl;
    //Question methods    
    public boolean AddQuestion(String question, String answer, int quiz_id) {return dl.InsertQuestion(question, answer, quiz_id);}
     public Question GetQuestionByQuestionId(int question_id)       {return dl.FetchQuestionByQuestionId(question_id);}
     public ArrayList<Question> GetQuestionsByQuizId(int quiz_id)   {return dl.FetchQuestionsByQuizId(quiz_id);}
     public ArrayList<Question> GetAllQuestions()                   {return dl.FetchAllQuestions();}
    //end of Question methods
    
    //Quiz methods
    public boolean AddQuiz(String title, int user_id)       {return dl.InsertQuiz(title, user_id);}
    public Quiz GetQuizByQuizId(int quiz_id)                {return dl.FetchQuizByQuizId(quiz_id);}
    public ArrayList<Quiz> GetQuizzesByTitle(String title)  {return dl.FetchQuizzesByTitle(title);}
    public ArrayList<Quiz> GetQuizzesByUserId(int user_id)  {return dl.FetchQuizzesByUserId(user_id);}
    public ArrayList<Quiz> GetAllQuizzes()           {return dl.FetchAllQuizzes();}
    //End of Quiz methods
    
    //User methods
    public boolean AddUser(String user_name, String password){
        //check to see if a user by the same name already exists. if not, insert it into database
        if (dl.FetchUserByUserName(user_name) == null) {return dl.InsertUser(user_name, password); } 
        else return false;
    }
    public User GetUserByUserId(int user_id)        { return dl.FetchUserByUserId(user_id); }
    public User GetUserByUserName(String user_name) { return dl.FetchUserByUserName(user_name); }
    public ArrayList<User>GetAllUsers()             { return dl.FetchAllUsers(); }
    //End of User methods
}
