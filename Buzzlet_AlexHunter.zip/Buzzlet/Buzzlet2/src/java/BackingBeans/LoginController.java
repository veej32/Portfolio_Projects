/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package BackingBeans;

import BusinessLayer.BuzzletBL;
import BusinessLayer.User;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

/**
 *
 * @author alex2
 */
@Named(value = "loginController")
@ViewScoped
public class LoginController implements Serializable{

    public LoginController() { }
    
    @Inject 
    private BuzzletBL bl;
    
    private String username;
    private String password;
    private String message;
    
    public String getUsername()              {return username;}
    public void setUsername(String username) {this.username = username;}
    
    public String getPassword()              {return password;}
    public void setPassword(String password) {this.password = password;}
    
    public String getMessage()               {return message;}
    public void setMessage(String message)   {this.message = message;}

    
    
    public String Login(){
        User user = bl.GetUserByUserName(username);
        String location;
        if (user == null || !user.getPassword().equals(password)) {
            message = "Invalid username or password. Please try again!";        
        }
        else { //successful credentials
            message = "Login Successful!";
            //get session object 
            HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
            
            //set user_id and username as session variables
            session.setAttribute("user_id", user.getUserId());
            session.setAttribute("user_name", username);
            
            //redirect user to main page with the message
        }
        //remove password & username values for security reasons
        password = null;
        username = null;
        //give user appropriate message
        return "index.xhtml?faces-redirect=true&msg=" + message;
    }
    
    public boolean CheckIfLoggedIn() {
            HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
            
            //see if user is logged in
            return session.getAttribute("user_id") != null && session.getAttribute("user_name") != null;

    }
    
    public String Logout(){
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
        session.invalidate();
        return "index.xhtml?faces-redirect=true&msg=Successfully Logged out!";
    }
    
}
