/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package BackingBeans;

import BusinessLayer.BuzzletBL;
import BusinessLayer.Question;
import BusinessLayer.Quiz;
import java.io.Serializable;
import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

/**
 *
 * @author alex2
 */
@Named(value = "quizTakingController")
@SessionScoped
public class QuizTakingController implements Serializable{

    @Inject 
    private BuzzletBL bl;

    @Inject
    private Quiz quiz;
    
    private Question question;
    
    private ArrayList<Question> questions;
    private int questionIndex;
    private ArrayList<String> studentAnswers;
    private String studentAnswer;
    private int correctAnswers;
    private ArrayList<String> resultsList;
    
    public Quiz getQuiz()                                   {return quiz;}
    public void setQuiz(Quiz quiz)                          {this.quiz = quiz;}

    public ArrayList<Question> getQuestions()               {return questions;}
    public void setQuestions(ArrayList<Question> questions) {this.questions = questions;}

    public int getQuestionIndex()                           {return questionIndex;}
    public void setQuestionIndex(int questionIndex)         {this.questionIndex = questionIndex;}

    public String getStudentAnswer()                        {return studentAnswer;}
    public void setStudentAnswer(String studentAnswer)      {this.studentAnswer = studentAnswer;}

    public int getAnswersCorrect()                          {return correctAnswers;}
    public void setCorrectAnswers(int correctAnswers)       { this.correctAnswers = correctAnswers;}

    public Question getQuestion()                           { return question; }
    public void setQuestion(Question question)              {this.question = question; }

    public ArrayList<String> getStudentAnswers()                    {return studentAnswers;}
    public void setStudentAnswers(ArrayList<String> studentAnswers) {this.studentAnswers = studentAnswers;}

    public ArrayList<String> getResultsList() { return resultsList; }
    public void setResultsList(ArrayList<String> resultsList) { this.resultsList = resultsList;  }
    
    
    
    public QuizTakingController() {
    }
    
    @PostConstruct
    public void InitializeQuiz() {
        HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);

        Integer quiz_id = (Integer) session.getAttribute("quiz_id");
        
        quiz = bl.GetQuizByQuizId(quiz_id);
        questions = bl.GetQuestionsByQuizId(quiz_id);
        
        questionIndex = 0;
        correctAnswers = 0;
        studentAnswers = new ArrayList<String>();
        resultsList = new ArrayList<String>();
        studentAnswer = "";
        correctAnswers = 0;
        
        question = questions.get(questionIndex);
        
    }
    
    public String AnswerQuestion () { 
        String msgResult;
        String actual = questions.get(questionIndex).getAnswer();
        if (CompareAnswer(actual, studentAnswer)) {
            msgResult = "Correct!";
            correctAnswers++;
        }
        else {
            msgResult = "Incorrect!";
        }
        studentAnswers.add(studentAnswer);
        resultsList.add(msgResult);
        if (questionIndex + 1< questions.size()) {
            questionIndex++;
            question = questions.get(questionIndex);
            return "TakeQuiz.xhtml?faces-redirect=true&msgResult=" + msgResult;     
        }
            return "TakeQuiz.xhtml?faces-redirect=true&quizEnd=" + "true";
          
    }
    
    public Boolean CompareAnswer(String actual, String studentResponce){
        return actual.equalsIgnoreCase(studentResponce);
    }
    
    public String NextQuestion() {
            return "TakeQuiz.xhtml?faces-redirect=true";
    }
    
    public ArrayList< ArrayList<String> > GetResults () {
        ArrayList< ArrayList<String> > results = new ArrayList<>();
        if (questions.size() == 0) {
            ArrayList<String> header = new ArrayList<>();
            header.add("");
            header.add("Question");
            header.add("Your Answer");
            header.add("Correct Answer");
            header.add("Result");
            results.add(header);
        }
        for (int i = 0; i<questions.size(); i++){
            ArrayList<String> result = new ArrayList<>();
            question = questions.get(i);
            result.add("#" + i);
            result.add(question.getQuestion());
            result.add(studentAnswers.get(i));
            result.add(question.getAnswer());
            result.add(resultsList.get(i));
            results.add(result);
        }
        return results;
    }
}
